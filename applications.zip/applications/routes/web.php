<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});
Route::get('/register', function () {
    return view('register');
});
Route::get('forgot-password',function(){
    return view('forgotPassword');
});
Auth::routes();
Route::post('/user/register', 'HomeController@UserRegister');
Route::post('/update-password', 'HomeController@UpdatePassword');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/application/select', 'ApplicationController@selectCourse');
Route::post('/application', 'ApplicationController@index');
Route::post('/application/parents/{id}', 'ApplicationController@parentsTab');
Route::post('/application/address/{id}', 'ApplicationController@addressTab');
Route::post('/application/qualification/{id}', 'ApplicationController@qualificationTab');
Route::post('/application/document/{id}', 'ApplicationController@documentTab');
Route::post('/application/subject/{id}', 'ApplicationController@subjectTab');
Route::post('/application/photo/{id}', 'ApplicationController@photoTab');
Route::post('/application/undertaking/{id}', 'ApplicationController@undertakingTab');
Route::post('/application/payment/{id}', 'ApplicationController@PaymentTab');
Route::get('/application/instructions', 'ApplicationController@instructions');


Route::post('/application/paymentRequest', 'ApplicationController@paymentRequest');
Route::get('/application/paymentResponse', 'ApplicationController@paymentResponse');
Route::get('/application/payment/response', 'ApplicationController@paymentResponse');
Route::get('/application/Download/{id}/{email}', 'ApplicationController@downloadForm');
Route::post('/application/save', 'ApplicationController@save');
Route::post('/application/save/upload', 'ApplicationController@fileUpload');
