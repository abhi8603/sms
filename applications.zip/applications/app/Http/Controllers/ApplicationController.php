<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use App\AesCipher;
use Auth;
use Session;

class ApplicationController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function instructions(){
      return view('application.instructions');
    }

    public function PaymentTab(){
      $pay_status=1;
      $stream="Commerce";
      return view('application.payment',compact('pay_status','stream'));
    }
    public function undertakingTab(){
      return view('application.undertakingStep');
    }
    public function photoTab(){
      return view('application.photoStep');
    }

    public function subjectTab(){
      $subjects=array();
      $stream="Commerce";
      return view('application.subjectStep',compact('subjects','stream'));
    }

    public function documentTab(){      
      return view('application.documentStep');
    }

    public function qualificationTab(){
      return view('application.qualificationStep');
    }

    public function addressTab(){
      return view('application.addressStep');
    }
    public function selectCourse(){      
      return view('application.selectCourse');
    }
    public function parentsTab(Request $request){
      return view('application.step2');
    }
    public function downloadForm($id,$email){
     ini_set('max_execution_time', '0');
       $formData=DB::table('applications')
       ->join('application_subjects','applications.id','application_subjects.app_id')
       ->where('applications.id',$id)->where('applications.email',Crypt::decrypt($email))->get();
    
      $formDoc=DB::table('application_documents')
      ->where('mobile',Auth::user()->mobile)
      ->where('course',$formData[0]->stream)
      ->where('email',Crypt::decrypt($email))->get();
       $pay_info=DB::table('sab_paisa_pg_trans')
       ->where('order_id',$formData[0]->receipt_id)
       ->where('course',$formData[0]->course)
       ->where('mobileNo',Auth::user()->mobile)->where('email',Auth::user()->email)->get();
    //   echo "<pre>"; print_r( $formDoc);exit; 
    //  echo "<pre>"; print_r($form_date);
		
     // echo "<pre>"; print_r($pay_info);exit;
  $subjects=array();
  return view('application.downloadForm',compact('formData','formDoc','pay_info','subjects'));
 
     //  $pdf = PDF::loadView('application.downloadForm',compact('form_date','pay_info'));
     //          return $pdf->download('medium.pdf');
     // return view('application.downloadForm');
    }

    public function paymentRequest(Request $request){

$spURL = null;
$spDomain = "https://securepay.sabpaisa.in/SabPaisa/sabPaisaInit";//"https://uatsp.sabpaisa.in/SabPaisa/sabPaisaInit";
 $username =env('SP_Username',null); //"Shr9905@sp"; //"Ish988@sp";
  $password =env('SP_Password',null); //"iUrw948VF";//"wF2F0io7gdNj";
$programID="3717";//"5666";
 $clientCode =env('SP_Client_Code',null);// "SIIPL";  //"NITE5";
 $authKey = env('SP_Authentication_KEY',null);//"xhzsSHf3O9i7hA59";  //"vuQy2eFx4q095E03";
 $authIV = env('SP_Authentication_IV',null);

 $txnId=strtotime("now").rand(10,100000);//$request->orderid;//"123323567";
 $txnAmt =env('FEE',null);
$URLsuccess = url('/')."/application/paymentResponse";
$URLfailure = url('/')."/application/paymentResponse";
$payerFirstName =$request->name;
$payerLastName ="";
$payerContact = $request->mobile;
$payerEmail =  $request->email;
$payerAddress = "Ranchi,Jharkhand";
$udf5=$request->course;
$udf6=$request->session()->get('receipt_id');
$spURL ="?clientName=".$clientCode."&usern=".$username."&pass=".$password."&amt=".$txnAmt."&txnId=".$txnId."&firstName=".$payerFirstName."&lstName=".$payerLastName."&contactNo=".$payerContact."&Email=".$payerEmail."&Add=".$payerAddress."&ru=".$URLsuccess."&failureURL=".$URLfailure."&udf5=".$udf5."&udf6=".$udf6;

$AesCipher = new AesCipher();
$spURL = $AesCipher->encrypt($authKey,$authIV,$spURL);
$spURL = str_replace("+", "%2B",$spURL);
$spURL="?query=".$spURL."&clientName=".$clientCode;
$spURL = $spDomain.$spURL;
return redirect($spURL);
}
public function paymentResponse(Request $request){
  $query = $request->input('query');
  $authKey = env('SP_Authentication_KEY',null);
  $authIV = env('SP_Authentication_IV',null);
  $decText = null;
  $AesCipher = new AesCipher();
  $query = str_replace("%2B","+",$query);
  $decText = $AesCipher->decrypt($authKey, $authIV, $query);
  $token = explode('&',$decText);
  $dataSize=sizeof($token);
  $i=0;
  $paymentresponse=array();
           for($j = 0; $j < $dataSize; $j++)
           {
               $information=explode('=',$token[$j]);
          $paymentresponse[$information[0]]=$information[1];
           }

         //  print_r($paymentresponse);exit;

           $whereClauese=array(
             "order_id"=>$paymentresponse['clientTxnId'],
             "PGTxnNo"=>$paymentresponse['PGTxnNo'],
             "SabPaisaTxId"=>$paymentresponse['SabPaisaTxId'],
             "issuerRefNo"=>$paymentresponse['issuerRefNo'],
           );
	
           $saveArray=array(
             "order_id"=>$paymentresponse['clientTxnId'],
             "form_id"=>$paymentresponse['udf6'],
             "course"=>$paymentresponse['udf5'],
             "pgRespCode"=>$paymentresponse['pgRespCode'],
             "PGTxnNo"=>$paymentresponse['PGTxnNo'],
             "SabPaisaTxId"=>$paymentresponse['SabPaisaTxId'],
             "issuerRefNo"=>$paymentresponse['issuerRefNo'],
             "authIdCode"=>$paymentresponse['authIdCode'],
             "amount"=>$paymentresponse['amount'],
             "clientTxnId"=>$paymentresponse['clientTxnId'],
             "firstName"=>$paymentresponse['firstName'],
             "lastName"=>$paymentresponse['lastName'],
             "payMode"=>$paymentresponse['payMode'],
             "email"=>$paymentresponse['email'],
             "mobileNo"=>$paymentresponse['mobileNo'],
             "spRespCode"=>$paymentresponse['spRespCode'],
             "cid"=>$paymentresponse['cid'],
             "bid"=>$paymentresponse['bid'],
             "clientCode"=>$paymentresponse['clientCode'],
             "payeeProfile"=>$paymentresponse['payeeProfile'],
             "transDate"=>$paymentresponse['transDate'],
             "m3"=>$paymentresponse['m3'],
             "challanNo"=>$paymentresponse['challanNo'],
             "reMsg"=>$paymentresponse['reMsg'],
             "orgTxnAmount"=>$paymentresponse['orgTxnAmount'],
             "programId"=>$paymentresponse['programId'],
             "midName"=>$paymentresponse['midName'],
           );
          $cnt= DB::table('sab_paisa_pg_trans')->where($whereClauese)->count();
           if($cnt==0){
            $save=DB::table('sab_paisa_pg_trans')->insertGetId($saveArray);
          }
          $appStatus=array(
            "email"=>Auth::user()->email,
            "s_phone_no"=>Auth::user()->mobile,
            "stream"=>$paymentresponse['udf5'],
          //  "form_id"=>$paymentresponse['udf6'],
          );
			
          DB::table('applications')->where($appStatus)->update(["receipt_id"=>$paymentresponse['clientTxnId']]);
          DB::table('applications')->where($appStatus)->update(["form_id"=>$paymentresponse['udf6']]);
        //  DB::table('applications')->where($appStatus)->update(["course"=>$paymentresponse['udf5']]);
			if($paymentresponse['pgRespCode']=="0000"){
          DB::table('applications')->where($appStatus)->update(["pay_status"=>$paymentresponse['pgRespCode']]);
          DB::table('applications')->where($appStatus)->update(["submit_status"=>1]);
			}else{
			  DB::table('applications')->where($appStatus)->update(["pay_status"=>$paymentresponse['pgRespCode']]);
          	  DB::table('applications')->where($appStatus)->update(["submit_status"=>0]);
			}
       //   DB::table('applications')->where($appStatus)->update(["status"=>1]);
          $request->session()->forget('receipt_id');
          return redirect('/home')->with([
       'message' =>$paymentresponse['reMsg']
        ]);

  }

  public function fileUpload(Request $request){
    $coursename=$request->course;
    $c_path=$request->c_path;
    $s_path=$request->s_path;
    $photo_path=$request->photo_path;
   
    if(isset($_FILES['signature'])){
     $errors= array();
     $file_name_s = $_FILES['photo']['name'];
    // echo $file_name_s;exit;
     $file_size_s  =$_FILES['photo']['size'];
     $file_tmp_s  =$_FILES['photo']['tmp_name'];
     $file_tmp_sp  =$_FILES['photo']['tmp_name'];
     $file_type_s =$_FILES['photo']['type'];
     $tmp_s = explode('.', $file_name_s);
     $file_ext_s = end($tmp_s);
   //  $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
     
     $extensions= array("jpeg","jpg","png");
   
     if(in_array($file_ext_s,$extensions)=== false){
        $errors[]="extension not allowed, please choose a JPEG or PNG file.";
     }
     
     if($file_size_s  > 2097152){
        $errors[]='File size must be excately 2 MB';
     }
   
     if(empty($errors)==true){
      if(move_uploaded_file($file_tmp_s,"assets/application/photo/".$file_name_s)){
        move_uploaded_file($file_tmp_sp,"application/assets/application/photo/".$file_name_s);
        $photoPath= "assets/application/photo/".$file_name_s;
      }else{
        echo "unable to upload Photo.Please try again.";
      }
     }
    }else{
      $photoPath= $photo_path;
    }

   if(isset($_FILES['signature'])){
     $file_name_s = $_FILES['signature']['name'];
     $file_size_s  =$_FILES['signature']['size'];
     $file_tmp_s  =$_FILES['signature']['tmp_name'];
     $file_tmp_sp  =$_FILES['signature']['tmp_name'];
     $file_type_s =$_FILES['signature']['type'];
     $tmp_s = explode('.', $file_name_s);
     $file_ext_s = end($tmp_s);
   //  $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
     
     $extensions= array("jpeg","jpg","png");
   
     if(in_array($file_ext_s,$extensions)=== false){
        $errors[]="extension not allowed, please choose a JPEG or PNG file.";
     }
     
     if($file_size_s  > 2097152){
        $errors[]='File size must be excately 2 MB';
     }
   
     if(empty($errors)==true){
      if(move_uploaded_file($file_tmp_s,"assets/application/sign/".$file_name_s)){
        move_uploaded_file($file_tmp_sp,"application/assets/application/sign/".$file_name_s);
        $signaturePath= "assets/application/sign/".$file_name_s;
      }else{
        echo "unable to upload Photo.Please try again.";
      }
     }
    }else{
      $signaturePath=$s_path;
    }
     if(isset($_FILES['cast_certi'])){
      $file_name_d = $_FILES['cast_certi']['name'];    
      $file_size_d  =$_FILES['cast_certi']['size'];
      $file_tmp_d  =$_FILES['cast_certi']['tmp_name'];
      $file_tmp_dp  =$_FILES['cast_certi']['tmp_name'];
      $file_type_d =$_FILES['cast_certi']['type'];
      $tmp_d = explode('.', $file_name_d);
      $file_ext_d = end($tmp_d);
    //  $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
      
      $extensions= array("pdf");
    
      if(in_array($file_ext_d,$extensions)=== false){
         $errors[]="extension not allowed, please choose PDF file.";
      }
      
      if($file_size_d  > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
    
      if(empty($errors)==true){
       if(move_uploaded_file($file_tmp_d,"assets/application/doc/".$file_name_d)){
         move_uploaded_file($file_tmp_dp,"application/assets/application/doc/".$file_name_d);
         $docsPath= "assets/application/doc/".$file_name_d;
       }else{
         echo "unable to upload Photo.Please try again.";
       }
      }else{
        print_r($errors);
        exit;
      }
    }else{
      $docsPath=$c_path;
    }
   
   $saveDocs=array(
      "email"=>Auth::user()->email,
      "mobile"=>Auth::user()->mobile,
      "course"=>$coursename,
      "photo"=>$photoPath,
      "signature"=>$signaturePath,
      "cast_doc"=>$docsPath,
    );
    $where=array(
      "email"=>Auth::user()->email,
      "mobile"=>Auth::user()->mobile,
      "course"=>$coursename,
    );
    $updateArray=array(
      "photo"=>$photoPath,
      "signature"=>$signaturePath,
      "cast_doc"=>$docsPath,
    );
      $cnt=DB::table('application_documents')->where($where)->count();     
       DB::table('users')->where("email",Auth::user()->email)
    ->where("mobile",Auth::user()->mobile)
    ->update(['profile_img'=>$photoPath]);
      if($cnt==0){
        DB::table('application_documents')->insert($saveDocs);
        echo "Documents Saved Succesfully";
      }else{
        DB::table('application_documents')->where($where)->update($updateArray);
        echo "Documents updated Succesfully";
      }

     exit;
  }

      public function save(Request $request){
           $eid = $request->data;
           $data=json_decode($eid);
          // print_r($data);
           $subjects=json_decode($request->subjects);
           unset($data->sub_type);
           unset($data->subject);
           $where=array(
             "s_phone_no"=>$data->s_phone_no,
             "email"=>$data->email,
             "stream"=>$data->stream,
           );
           //print_r($where);
          $cnt=DB::table('applications')->where($where)->get();
         // print(  $cnt);exit;
          if(count($cnt)==0){
          $saveid=DB::table('applications')->insertGetId((array) $data);
          $receipt_id="Intermediate/2021-23/000".$saveid;
          DB::table('applications')->where('id',$saveid)->update(['receipt_id'=>$receipt_id]);
          DB::table('applications')->where('id',$saveid)->update(['form_id'=>$receipt_id]);
          $request->session()->put('receipt_id', $receipt_id);
         }else{
           $update=DB::table('applications')->where($where)->update((array) $data);
           $saveid=$cnt[0]->id;
           $receipt_id="Intermediate/2021-23/000".$saveid;
           DB::table('applications')->where('id',$saveid)->update(['receipt_id'=>$receipt_id]);
           $request->session()->put('receipt_id', $receipt_id);
         }

         $deletewhere=array(
           "app_id"=>$saveid,
           "user_mobile"=>$data->s_phone_no,
           "user_email"=>$data->email,
         );
         DB::table('application_subjects')->where($deletewhere)->delete();
         for($i=0;$i<count($subjects);$i++){
          $subs=array(
              "app_id"=>$saveid,
              "user_mobile"=>$data->s_phone_no,
              "user_email"=>$data->email,
              "sub_type"=>$subjects[$i]->sub_type,
              "sub_name"=>$subjects[$i]->subject,
            );

            DB::table('application_subjects')->insert($subs);

         }
        if($saveid){
          echo $saveid;
        }else{
          echo 0;
        }
    }

    public function index(Request $request)
    {
      $stream=$request->stream;
      Session::put('selected_stream', $stream);
      $formData=DB::table('applications')->where('stream',$stream)->where('email',Auth::user()->email)->where('s_phone_no',Auth::user()->mobile)->limit(1)->get();
      $docs=DB::table('application_documents')->where('course',$stream)->where('email',Auth::user()->email)->where('mobile',Auth::user()->mobile)->get();

      if(count($formData) > 0){
        $submitted=$formData[0]->submit_status;
      }else{
        $submitted=0;
      }
      if(count($formData) > 0){
        $pay_status=$formData[0]->pay_status;
      }else{
        $pay_status=0;
      }
    //  echo $submitted;exit;
  //    print_r(count($subjects));exit;
      return view('application.application',compact('formData','docs','stream','submitted','pay_status'));
    }
}
