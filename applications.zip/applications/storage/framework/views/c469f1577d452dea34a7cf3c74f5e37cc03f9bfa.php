
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/forn-wizard/css/forn-wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/formwizard/smart_wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/formwizard/smart_wizard_theme_dots.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="contents">

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<div class="shop-breadcrumb">

				<div class="breadcrumb-main">
					<h4 class="text-capitalize breadcrumb-title">Parents Information</h4>
					<div class="breadcrumb-action justify-content-center flex-wrap">
						<div class="action-btn">

							<div class="form-group mb-0">
								<div class="input-container icon-left position-relative">
									<span class="input-icon icon-left">
										<span data-feather="calendar"></span>
									</span>
									<input type="text" class="form-control" value="<?php echo date('d M Y'); ?>" placeholder="<?php echo date('d M Y'); ?>" readonly>
									<span class="input-icon icon-right">
										<span data-feather="chevron-down"></span>
									</span>
								</div>
							</div>
						</div>
						
						
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<div class="container-fluid">
	<div class=" checkout wizard7 global-shadow border px-sm-50 px-20 pt-sm-50 py-30 mb-30 bg-white radius-xl w-100">
		<div class="row justify-content-center">
			<div class="col-xl-8 col-12">
				<div class="checkout-progress-indicator content-center">
					<div class="checkout-progress justify-content-center">
					<div class="step completed " id="1">
							<span class="las la-check"></span>
							<span>Personal</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkoutin.svg')); ?>" alt="img" class="svg"></div>
						<div class="step current" id="2">
							<span>2</span>
							<span>Parents</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="3">
							<span>3</span>
							<span>Address</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="4">
							<span>4</span>
							<span>Qualification</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="5">
							<span>5</span>
							<span>Documents</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="6">
							<span>6</span>
							<span>Subjects</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="7">
							<span>7</span>
							<span>Photo & Signature</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="8">
							<span>8</span>
							<span>Undertaking</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="9">
							<span>9</span>
							<span>Payment</span>
						</div>
					</div>
				</div><!-- ends: .checkout-progress-indicator -->


				<div class="row justify-content-center">
				<div class="col-lg-12">
                        <div class="card checkout-shipping-form px-30 pt-2 pb-30 border-color">
                            <div class="card-header">
                                <h6>Personal Information </h6>
                            </div>
                            <div class="card-body py-md-30">
                                <form method="post" action="<?php echo e(url('application/address/1')); ?>">
								<?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6 mb-25">
										<div class="form-group">
										<label>Father’s Name <span style="color:red;">*</span></label>
										  <input type="text" value="<?php echo e(isset($formData[0]->f_name) ? $formData[0]->f_name : old('f_name')); ?>" class="form-control ih-medium ip-gray radius-xs b-light" name="f_name" id="f_name"  required>
										</div>
                                        </div>
                                        <div class="col-md-6 mb-25">
										<div class="form-group">
										<label>Mother’s Name  <span style="color:red;">*</span></label>
										<input type="text" value="<?php echo e(isset($formData[0]->m_name) ? $formData[0]->m_name : old('m_name')); ?>" class="form-control ih-medium ip-gray radius-xs b-light" name="m_name" id="m_name" required >
										</div>
                                        </div>
                                        <div class="col-md-6 mb-25">
										<div class="form-group">
                              
								<label>Parent's Phone No <span style="color:red;">*</span></label>
									<input type="number" onblur="checkLengthMobile(this)" maxlength="10" value="<?php echo e(isset($formData[0]->p_phone) ? $formData[0]->p_phone : old('p_phone')); ?>" class="form-control ih-medium ip-gray radius-xs b-light" name="p_phone" id="p_phone"   required>
                                </div>
										</div>
                                        <div class="col-md-6 mb-25">
										<div class="form-group form-group-calender mb-20">
										<label>Guardian Name (If father is dead)</label>
										<input type="text" value="<?php echo e(isset($formData[0]->g_name) ? $formData[0]->g_name : old('g_name')); ?>" class="form-control ih-medium ip-gray radius-xs b-light" name="g_name" id="g_name" >

                           			      </div>
                                        </div>
                                        <div class="col-md-6 mb-25">
										<label>Guardian Phone No</label>
										<input type="number" maxlength="10" onblur="checkLengthMobile(this)" value="<?php echo e(isset($formData[0]->g_phone) ? $formData[0]->g_phone : old('g_phone')); ?>" class="form-control ih-medium ip-gray radius-xs b-light" name="g_phone" id="g_phone" >

                                        </div>
                                        <div class="col-md-6 mb-25">
										<label>Occupation of (Father / Mother / Guardian) <span style="color:red;">*</span></label>
															<input type="text" value="<?php echo e(isset($formData[0]->occupation) ? $formData[0]->occupation : old('occupation')); ?>" class="form-control ih-medium ip-gray radius-xs b-light" name="occupation" id="occupation"  required>
                                        </div>
                                    </div>
									<div class="button-group d-flex pt-3 justify-content-between flex-wrap" style="float: right;">																	
											<button href="<?php echo e(url('application/address/1')); ?>" class="btn text-white btn-primary btn-default btn-squared text-capitalize m-1">Save & Next<i class="ml-10 mr-0 las la-arrow-right"></i></button>
										</div>
                                </form>
								<div class="button-group d-flex pt-3 justify-content-between flex-wrap" style="float: left;margin-top:-7px;">
										<form method="post" action="<?php echo e(url('/application')); ?>">
										<?php echo csrf_field(); ?>
										<button class="btn btn-warning btn-default btn-squared btn-transparent-warning  text-capitalize m-1"><i class="las la-arrow-left mr-10"></i>Previous</button>
										</form>
							  </div>
                            </div>
                        </div>
                        <!-- ends: .card -->

                    </div>
				
				</div>				
			</div><!-- ends: col -->
		</div>
	</div><!-- ends: .global-shadow -->
</div>


</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script src="<?php echo e(URL::asset('assets/plugins/formwizard/jquery.smartWizard.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets/plugins/formwizard/fromwizard.js')); ?>"></script>
<script type="text/javascript">
function checkLengthAadhar(el) {
  if (el.value.length > 12) {
	$.notify("Please Enter Valid 12 digit Aadhar No.", "error");
	el.value="";
	return false;
   
  }
  if (el.value.length < 12) {
	$.notify("Please Enter Valid 12 digit Aadhar No.", "error");
	el.value="";
	return false;
   
  }
}
function checkLengthMobile(el) {
  if (el.value.length != 10) {
	 // alert(el.value.length);
	$.notify("Please Enter Valid 10 digit Mobile No.", "error");
	el.value="";
	return false;
   
  }
}

function CalculatePercentage(el){
	var tmo=$("#tmo").val();
//	alert(el.value);
	$("#percentage_secured").val(parseFloat((tmo/el.value)*100).toFixed(2));
}

function myFunction() {
	var name=document.getElementById('name').value;
	document.getElementById("pname").value=name;
	document.getElementById("t").href = "https://translate.google.co.in/?sl=en&tl=hi&text="+name+"&op=translate";
}
</script>
<script>
function validateSize(input) {
  const fileSize = input.files[0].size / 1024 / 1024; // in MiB
  if (fileSize > 2) {
    alert('File size exceeds 2 MiB');
    // $(file).val(''); //for clearing with Jquery
  } else {
    // Proceed further
  }
}
function loadImg_cast(input){
//	alert(input.files[0].type);application/pdf
//	if(file.type.match('video.*'))
if(input.files[0].type=="application/pdf"){

}else{
	$.notify("Please select Valid PDF File.", "error");
	document.getElementById('cast_certi_p').src = "";
	return false
}
	const fileSize = input.files[0].size / 1024 / 1024; // in MiB
  if (fileSize > 2) {
	$("#cast_certi").val(''); 
	$.notify("File size exceeds 2 MiB.", "error");
	document.getElementById('cast_certi_p').src = "";
	return false
    // $(file).val(''); //for clearing with Jquery
  } else {
    // Proceed further
	$('#cast_certi_p').attr('src', URL.createObjectURL(event.target.files[0]));
  }
	
}
function loadImg_p(input){
	if(input.files[0].type=="image/png" || input.files[0].type=="image/jpeg" || input.files[0].type=="image/jpg"){

}else{
	$.notify("Please select Valid Image File.", "error");
	document.getElementById('photo_p').src = "";
	return false
}
	const fileSize = input.files[0].size / 1024 / 1024; // in MiB
  if (fileSize > 2) {
	$("#photo").val(''); 
	$.notify("File size exceeds 2 MiB.", "error");
	document.getElementById('photo_p').src = "";
	return false
    // $(file).val(''); //for clearing with Jquery
  } else {
    // Proceed further
	$('#photo_p').attr('src', URL.createObjectURL(event.target.files[0]));
  }
	
   
}

function loadImg_s(input){
	if(input.files[0].type=="image/png" || input.files[0].type=="image/jpeg" || input.files[0].type=="image/jpg"){

}else{
	$.notify("Please select Valid Image File.", "error");
	document.getElementById('signature_p').src = "";
	return false
}
	const fileSize = input.files[0].size / 1024 / 1024; // in MiB
  if (fileSize > 2) {
	$("#signature").val(''); 
	$.notify("File size exceeds 2 MiB.", "error");
	document.getElementById('signature_p').src = "";
	return false
  
  } else {
	$('#signature_p').attr('src', URL.createObjectURL(event.target.files[0]));
    // Proceed further
  }
  
}
$(document).ready(function(){
	var o_study_o=$(".o_study:checked").val()
	if(o_study_o=="Yes"){
		$(".sp").show();
	}else{
		$(".sp").hide();
	}
	$(".o_study").on("change",function(){
		var o_study_o=$(".o_study:checked").val()
		//alert(o_study_o);
		if(o_study_o=="Yes"){
		$(".sp").show();
	}else{ //alert();
		$(".sp").hide();
	}
	})

	var castname=$("input:radio.cast:checked").val();//alert(castname);
	if(castname=="Schedule Tribe" || castname=="Schedule Cast" || castname=="Other Backward Class"){
			$("#ct_cast").show();
		}else{
			$("#ct_cast").hide();
		}
	$(".cast").change(function(){
		if(this.value=="Schedule Tribe" || this.value=="Schedule Cast" || this.value=="Other Backward Class"){
			$("#ct_cast").show();
		}else{
			$("#ct_cast").hide();
		}
	});

	$("#file_upload").click(function(evt){
		evt.preventDefault();
	//	alert();exit;
		var fd = new FormData();
        var photo = $('#photo')[0].files;
		if(photo[0]=="" || photo[0]===null || photo[0]==undefined){
			$.notify("Please select Valid Photo File.", "error");
			return false;
		}
		var signature = $('#signature')[0].files;
		if(signature[0]=="" || signature[0]==null || signature[0]==undefined){
			$.notify("Please select Valid Signature File.", "error");
			return false;
		}
			var castname=$("input:radio.cast:checked").val();

			/*if( $('#ct_cast').css('display') != 'none' )*/ 
			if(castname=="Schedule Tribe" || castname=="Schedule Cast" || castname=="Other Backward Class") {
			var cast_certi = $('#cast_certi')[0].files;
			if(cast_certi[0]=="" || cast_certi[0]==null || cast_certi[0]==undefined){
				$.notify("Please select Valid Cast Certificate File.", "error");
				return false;
			}else{
			fd.append('cast_certi',cast_certi[0]);
			}
		}else{
		var cast_certi = $('#cast_certi')[0].files;
			fd.append('cast_certi',null);
		}
		fd.append('photo',photo[0]);
		fd.append('signature',signature[0]);
		
		fd.append('course',$("#course").val());
		//console.log(fd);exit;
		var _url = $("#_url").val();
		/*alert(_url);*/
		$.ajax({
		type: "POST",
			 url: _url + '/application/save/upload',
			 data: fd,
			 cache: false,
			 enctype: 'multipart/form-data',
       	     processData: false,
             contentType: false,	
      		 
			 success: function ( data ) {
			 	
				$.notify(data, "error");
			},
			 error: function (jqXHR, exception) {
				 	return false;
var msg = '';
if (jqXHR.status === 0) {
msg = 'Not connect.\n Verify Network.';
} else if (jqXHR.status == 404) {
msg = 'Requested page not found. [404]';
} else if (jqXHR.status == 500) {
msg = 'Internal Server Error [500].';
} else if (exception === 'parsererror') {
msg = 'Requested JSON parse failed.';
} else if (exception === 'timeout') {
msg = 'Time out error.';
} else if (exception === 'abort') {
msg = 'Ajax request aborted.';
} else {
msg = 'Uncaught Error.\n' + jqXHR.responseText;
}
alert(msg);
},

	 });
	});

	var stream=$("#stream").val();
//	$('input:radio[name="course"][value="'+stream+'"]').attr('checked',true);
	var pay_status=$("#pay_status").val();
//	alert(pay_status);
	if(pay_status=="0000"){
		$("#pay").prop("disabled", true);
	}
	var sub_status=$("#sub_status").val();
	if(sub_status==1){
		$("#applicationForm input").prop("disabled", true);
	}

	$("input[name='course']").change(function() {
	//	alert();
  //  var index = $(this).attr('name').substr(2);
		var classname=this.value;

		if(classname=='Commerce'){
				$("#subs").empty();
				$("#subs").append('<table id="example" class="table card-table table-vcenter  table-warning">\
				<thead>\
				<tr>\
					<th>Subject</th>\
					<th class="Commerce">Commerce</th>\
				</tr>\
			</thead>\
			<tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr></tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Accountancy (ACT)" class="subject form-control" readonly/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Business Studies (BST)" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="" class="subject form-control"/></td>\
			</tr>\
			</table>');
			}

		if(classname=='Science'){
				$("#subs").empty();
				$("#subs").append('<table id="example"  class="table card-table table-vcenter  table-warning">\
				<thead>\
				<tr>\
					<th>Subject</th>\
					<th class="Science">Science</th>\
				</tr>\
			</thead>\
			<tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr></tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Physics (PHY)" class="subject form-control" readonly/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Chemistry (CHE)" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="sub_type form-control" readonly/> </td>\
				<td><input type="text"  name="subject" value="" class="subject form-control"/></td>\
			</tr>\
			</table>');
			}

	if(classname=='Arts'){
			$("#subs").empty();
			$("#subs").append('<table id="example"  class="table card-table table-vcenter  table-warning">\
			<thead>\
			<tr>\
				<th>Subject</th>\
				<th class="arts">Arts</th>\
			</tr>\
		</thead>\
		<tbody>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr></tbody>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" value="NA" name="subject" class="subject form-control" readonly/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" name="subject" value="" class="subject form-control"/></td>\
		</tr>\
		</table>');
		}
});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/stpaulscollege.co.in/cloud.stpaulscollege.co.in/applications/resources/views/application/step2.blade.php ENDPATH**/ ?>