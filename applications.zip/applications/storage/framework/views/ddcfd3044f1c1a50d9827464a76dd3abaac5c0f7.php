<!doctype html>
<html lang="en" dir="ltr">


<!-- Mirrored from demo.jsnorm.com/html/strikingdash/strikingdash/ltr/inbox.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Sep 2021 03:31:10 GMT -->
<head>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
		<meta http-equiv="Pragma" content="no-cache" />
  		<meta http-equiv="Expires" content="0" />
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta content="Bucksofttech pvt. ltd,abhijeet,online application" name="description">
		<meta content="Spruko Technologies Private Limited" name="author">
		<meta name="keywords" content="Bucksofttech pvt. ltd,abhijeet,online application"/>
    <title><?php echo app_config('AppName') ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet">

    <!-- inject:css-->

	<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/plugin.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/style.css')); ?>">

    <!-- endinject -->

    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset(app_config('AppFav')); ?>">
	

<?php echo $__env->yieldContent('style'); ?>

</head>

<body class="layout-light top-menu overlayScroll">
    <div class="mobile-search"></div>

    <div class="mobile-author-actions"></div>
    <header class="header-top">
        <nav class="navbar navbar-light">
            <div class="navbar-left">
                <a href="#" class="sidebar-toggle">
                    <img class="svg" src="img/svg/bars.svg" alt="img"></a>
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>"><img style="height:64px;" class="svg dark" src="<?php echo "https://cloud.stpaulscollege.co.in/".app_config('AppLogo'); ?>" alt="Logo"><img class="light" src="img/logo_white.png" alt="img"></a>
                
                <div class="top-menu">

                    <div class="strikingDash-top-menu position-relative">
                        <ul>
						<li>
                        <a href="<?php echo e(url('/home')); ?>" class="active">  
						<span data-feather="home" class="nav-icon"></span>                          
                            <span class="menu-text">Dashboard</span>                           
                        </a>
                    </li>
                            <li class="has-subMenu">
								
                                <a href="#" class="">
								<span data-feather="activity" class="nav-icon"></span>	
								Application</a>
								
                                <ul class="subMenu">
								<li>
                                        <a class="" href="<?php echo e(url('/application/instructions')); ?>">Instructions</a>
                                    </li>
                                    <li>
                                        <a class="" href="<?php echo e(url('/application/select')); ?>">Apply</a>
                                    </li>
                                    <li>
                                        <a class="" href="<?php echo e(url('/home')); ?>">My Application Status</a>
                                    </li>                                   
                                </ul>
                            </li>             
                        
                        </ul>
                    </div>

                </div>
            </div>
            <!-- ends: navbar-left -->

            <div class="navbar-right">
                <ul class="navbar-right__menu">                   

                    <li class="nav-author">
                        <div class="dropdown-custom">
                            <a href="javascript:;" class="nav-item-toggle">
							<?php if(Auth::user()->profile_img == null): ?>
												<img src="<?php echo "https://cloud.stpaulscollege.co.in/".app_config('AppLogo'); ?>" alt="img" class="rounded-circle">
												<?php else: ?>
												<img src="../assets/images/users/16.jpg" alt="img" class="rounded-circle">
												<?php endif; ?>							
							</a>
                            <div class="dropdown-wrapper">
                                <div class="nav-author__info">
                                    <div class="author-img">
									<?php if(Auth::user()->profile_img == null): ?>
												<img src="<?php echo "https://cloud.stpaulscollege.co.in/".app_config('AppLogo'); ?>" alt="img" class="rounded-circle">
												<?php else: ?>
												<img src="../assets/images/users/16.jpg" alt="img" class="rounded-circle">
												<?php endif; ?>
                                      
                                    </div>
                                    <div>
                                        <h6><?php echo e(Auth::user()->name); ?></h6>
                                        <span>Applicant</span>
                                    </div>
                                </div>
                                <div class="nav-author__options">
                                    
                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav-author__signout">
									<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
																			 <?php echo csrf_field(); ?>
																				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
																				
																	 </form>  
																	 
																	 <span data-feather="log-out"></span> Sign Out
																	 </a>
                                </div>
                            </div>
                            <!-- ends: .dropdown-wrapper -->
                        </div>
                    </li>
                    <!-- ends: .nav-author -->
                </ul>
                <!-- ends: .navbar-right__menu -->
                <div class="navbar-right__mobileAction d-md-none">
                    <a href="#" class="btn-search">
                        <span data-feather="search"></span>
                        <span data-feather="x"></span></a>
                    <a href="#" class="btn-author-action">
                        <span data-feather="more-vertical"></span></a>
                </div>
            </div>
            <!-- ends: .navbar-right -->
        </nav>
    </header>
    <main class="main-content">
	<aside class="sidebar">
            <div class="sidebar__menu-group">
                <ul class="sidebar_nav">
                    <li class="menu-title">
                        <span>Main menu</span>
                    </li>
                    <li class="has-child">
                        <a href="#" class="">
                            <span data-feather="home" class="nav-icon"></span>
                            <span class="menu-text">Dashboard</span>
                            <span class="toggle-icon"></span>
                        </a>
                        <ul>
                            <li>
                                <a class="" href="index.html">Social Media</a>
                            </li>
                            <li>
                                <a class="" href="business.html">FineTech /
                                    Business</a>
                            </li>
                            <li>
                                <a class="" href="performance.html">Site
                                    Performance</a>
                            </li>
                            <li>
                                <a class="" href="ecommerce.html">Ecommerce</a>
                            </li>
                            <li>
                                <a class="" href="crm.html">
                                    CRM</a>
                            </li>
                            <li>
                                <a class="" href="sales.html">
                                    Sales Performance</a>
                            </li>
                        </ul>
                    </li>
				</ul>
			</div>
	</aside>
		<?php echo $__env->yieldContent('content'); ?>
        <footer class="footer-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-copyright">
                            <p>2021 @<a href="#">Bucksofttech</a>
                            </p>
                        </div>
                    </div>
                   
                </div>
            </div>
        </footer>
    </main>
    <div id="overlayer">
        <span class="loader-overlay">
            <div class="atbd-spin-dots spin-lg">
                <span class="spin-dot badge-dot dot-primary"></span>
                <span class="spin-dot badge-dot dot-primary"></span>
                <span class="spin-dot badge-dot dot-primary"></span>
                <span class="spin-dot badge-dot dot-primary"></span>
            </div>
        </span>
    </div>
    <a href="#" style="display: none;" class="customizer-trigger">
        <span data-feather="settings"></span></a>
    <div class="customizer-wrapper" style="display: none;">
        <div class="customizer">
            <div class="customizer__head">
                <h4 class="customizer__title">Customizer</h4>
                <span class="customizer__sub-title">Customize your overview page layout</span>
                <a href="#" class="customizer-close">
                    <span data-feather="x"></span></a>
            </div>
            <div class="customizer__body">               
                <!-- ends: .customizer__single -->

                <div class="customizer__single">
                    <h4>Sidebar Type</h4>
                    <ul class="customizer-list d-flex l_sidebar">
                        <li class="customizer-list__item">
                            <a href="#" data-layout="light" class="active">
                                <img src="img/light.png" alt="">
                                <i class="fa fa-check-circle"></i>
                            </a>
                        </li>
                        <li class="customizer-list__item">
                            <a href="#" data-layout="dark">
                                <img src="img/dark.png" alt="">
                                <i class="fa fa-check-circle"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- ends: .customizer__single -->

                <div class="customizer__single">
                    <h4>Navbar Type</h4>
                    <ul class="customizer-list d-flex l_navbar">
                        <li class="customizer-list__item">
                            <a href="#" data-layout="side" class="">
                                <img src="img/side.png" alt="">
                                <i class="fa fa-check-circle"></i>
                            </a>
                        </li>
                        <li class="customizer-list__item top">
                            <a href="#" data-layout="top" class="active">
                                <img src="img/top.png" alt="">
                                <i class="fa fa-check-circle"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- ends: .customizer__single -->
            </div>
        </div>
    </div>
    <div class="overlay-dark-sidebar"></div>
    <div class="customizer-overlay"></div>
	<input type="hidden" id="_url" value="<?php echo e(url('/')); ?>">   
    <!-- inject:js-->
	<script src="<?php echo e(URL::asset('assets/js/plugins.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets/js/script.min.js')); ?>"></script>
<script>
     $.ajaxSetup({
         headers: {
             'X-CSRF-Token': $('input[name="_token"]').val()
         }
     });
  </script>
   

<?php echo $__env->yieldContent('script'); ?>
    <!-- endinject-->
</body>


</html><?php /**PATH C:\xampp\htdocs\applications\resources\views/header.blade.php ENDPATH**/ ?>