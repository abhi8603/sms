
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/forn-wizard/css/forn-wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/formwizard/smart_wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/formwizard/smart_wizard_theme_dots.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="contents">

<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<div class="shop-breadcrumb">

				<div class="breadcrumb-main">
					<h4 class="text-capitalize breadcrumb-title">Qualification</h4>
					<div class="breadcrumb-action justify-content-center flex-wrap">
						<div class="action-btn">

							<div class="form-group mb-0">
								<div class="input-container icon-left position-relative">
									<span class="input-icon icon-left">
										<span data-feather="calendar"></span>
									</span>
									<input type="text" class="form-control" value="<?php echo date('d M Y'); ?>" placeholder="<?php echo date('d M Y'); ?>" readonly>
									<span class="input-icon icon-right">
										<span data-feather="chevron-down"></span>
									</span>
								</div>
							</div>
						</div>
						
						
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<div class="container-fluid">
	<div class=" checkout wizard7 global-shadow border px-sm-50 px-20 pt-sm-50 py-30 mb-30 bg-white radius-xl w-100">
		<div class="row justify-content-center">
			<div class="col-xl-8 col-12">
				<div class="checkout-progress-indicator content-center">
					<div class="checkout-progress justify-content-center">
					<div class="step completed " id="1">
							<span class="las la-check"></span>
							<span>Personal Information</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkoutin.svg')); ?>" alt="img" class="svg"></div>
						<div class="step completed" id="2">
							<span class="las la-check"></span>
							<span>Parents Information</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkoutin.svg')); ?>" alt="img" class="svg"></div>
						<div class="step completed" id="3">
							<span class="las la-check"></span>
							<span>Address</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkoutin.svg')); ?>" alt="img" class="svg"></div>
						<div class="step completed" id="4">
							<span class="las la-check"> </span>
							<span>Qualification</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkoutin.svg')); ?>" alt="img" class="svg"></div>
						<div class="step completed " id="5">
							<span class="las la-check"></span>
							<span>Documents</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step current" id="6">
							<span>6</span>
							<span>Subjects</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="7">
							<span>7</span>
							<span>Photo & Signature</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="8">
							<span>8</span>
							<span>Undertaking</span>
						</div>
						<div class="current"><img src="<?php echo e(URL::asset('assets/img/svg/checkout.svg')); ?>" alt="img" class="svg"></div>
						<div class="step" id="9">
							<span>9</span>
							<span>Payment</span>
						</div>
					</div>
				</div><!-- ends: .checkout-progress-indicator -->
				<div class="row justify-content-center">
					<div class="col-xl-7 col-lg-8 col-sm-10">
						<div class="card checkout-shipping-form px-30 pt-2 pb-30 border-color">
							<div class="card-header border-bottom-0 pb-sm-0 pb-1 px-0">
								<h4 class="fw-500">2. Please setup your profile</h4>
							</div>
							<div class="card-body p-0">
								<div class="edit-profile__body">
									<form>
										<div class="form-group">
											<label for="name31">First name</label>
											<input type="text" class="form-control" id="name31" placeholder="First Name">
										</div>
										<div class="form-group">
											<label for="name62">Last name</label>
											<input type="text" class="form-control" id="name62" placeholder="Last Name">
										</div>
										<div class="form-group">
											<label for="name31">Email Address</label>
											<input type="text" class="form-control" id="name31" placeholder="Username@email.com">
										</div>
										<div class="form-group">
											<label for="name62">Address</label>
											<input type="text" class="form-control" id="name62" placeholder="Enter Address">
										</div>
										</form>
                                   
										<div class="button-group d-flex pt-3 justify-content-between flex-wrap">
                                        <a href="<?php echo e(url('/application/document/1')); ?>" class="btn btn-light btn-default btn-squared fw-400 text-capitalize m-1"><i class="las la-arrow-left mr-10"></i>Previous</a>
									
											
											<a href="<?php echo e(url('application/photo/1')); ?>" class="btn text-white btn-primary btn-default btn-squared text-capitalize m-1">Save & Next<i class="ml-10 mr-0 las la-arrow-right"></i></a>
										</div>
									
								</div>
							</div>
						</div><!-- ends: .card -->
					</div><!-- ends: .col -->
				</div>
			</div><!-- ends: col -->
		</div>
	</div><!-- ends: .global-shadow -->
</div>


</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\applications\resources\views/application/subjectStep.blade.php ENDPATH**/ ?>