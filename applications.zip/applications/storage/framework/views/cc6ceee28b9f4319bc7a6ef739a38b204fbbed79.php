
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="contents">
					<div class="container-fluid">

                        <div class="row">
                    <div class="col-lg-12">

                        <div class="breadcrumb-main">
                            <h4 class="text-capitalize breadcrumb-title">Select Stream</h4>
                            <div class="breadcrumb-action justify-content-center flex-wrap">
                            <ul class="atbd-breadcrumb nav">
                                        <li class="atbd-breadcrumb__item">

                                            <a href="#">

                                                <span class="la la-home"></span>
                                            </a>
                                            <span class="breadcrumb__seperator">
                                                <span class="la la-slash"></span>
                                            </span>


                                        </li>
                                        <li class="atbd-breadcrumb__item">
                                            <a href="#">Apply</a>
                                            <span class="breadcrumb__seperator">
                                                <span class="la la-slash"></span>
                                            </span>
                                        </li>


                                        <li class="atbd-breadcrumb__item">
                                            <span>Select Course</span>
                                        </li>
                                    </ul>                     
                            </div>
                        </div>

                    </div>
                </div>

                        <div class="row">
                        <div class="col-md-12">
    							<div class="col-md-6">
    								<div class="card card-horizontal card-default card-md mb-4">
    									<div class="card-header">
    										<h3 class="card-title">Select Stream</h3>
    									</div>
                                    	<div class="card-body">
                                        <form method="post" action="<?php echo e(url('/application')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
    						<label>Session : <span style="color:red;">2021-2023</span></label>
    	                     	</div>

                                 <div class="form-group">
    						<label>Stream <span style="color:red;">*</span></label>
                            <select class="form-control" name="stream" required>
                            <option value="">Please Select</option>
                            <option value="Science">Science</option>
                            <option value="Commerce">Commerce</option>
                            <option value="Arts">Arts</option>

                            </select>
    	                     	</div>
                                 <div class="form-group">
                                 <input type="submit" value="Submit" class="btn btn-info"/>
                                 </div>

                                 </form>

                                        </div>

                                        </div>
                                </div>

                             <!--   <div class="col-md-6">
    								<div class="card card-horizontal card-default card-md mb-4">
    									<div class="card-header">
    										<h3 class="card-title">Instructions</h3>
    									</div>
                                    	<div class="card-body">
                                        <div class="form-group">
    						            <ul style="list-style:disc;">
                                            <li>User's can submit multiple form</li>
                                            <li>User's can submit multiple form</li>
                                        </ul>
                            
                              	</div>

                               

                                        </div>

                                        </div>
                                </div>-->
                                </div>
                        </div>


                        </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/stpaulscollege.co.in/cloud.stpaulscollege.co.in/applications/resources/views/application/selectCourse.blade.php ENDPATH**/ ?>