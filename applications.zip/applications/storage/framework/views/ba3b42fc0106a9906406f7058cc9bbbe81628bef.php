<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>

		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta content="Clont - Bootstrap Webapp Responsive Dashboard Simple Admin Panel Premium HTML5 Template" name="description">
		<meta content="Spruko Technologies Private Limited" name="author">
		<meta name="keywords" content="Admin, Admin Template, Dashboard, Responsive, Admin Dashboard, Bootstrap, Bootstrap 4, Clean, Backend, Jquery, Modern, Web App, Admin Panel, Ui, Premium Admin Templates, Flat, Admin Theme, Ui Kit, Bootstrap Admin, Responsive Admin, Application, Template, Admin Themes, Dashboard Template"/>
		<link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('assets/css/skin-modes.css')); ?>" rel="stylesheet" />

		<!--Horizontal css -->
        <link id="effect" href="<?php echo e(URL::asset('assets/plugins/horizontal-menu/dropdown-effects/fade-up.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(URL::asset('assets/plugins/horizontal-menu/horizontal.css')); ?>" rel="stylesheet" />

		<!-- P-scroll bar css-->
		<link href="<?php echo e(URL::asset('assets/plugins/p-scrollbar/p-scrollbar.css')); ?>" rel="stylesheet" />

		<!---Icons css-->
		<link href="<?php echo e(URL::asset('assets/plugins/web-fonts/icons.css')); ?>" rel="stylesheet" />
		<link href="<?php echo e(URL::asset('assets/plugins/web-fonts/font-awesome/font-awesome.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(URL::asset('assets/plugins/web-fonts/plugin.css')); ?>" rel="stylesheet" />

		<!-- Switcher css -->
		<link  href="<?php echo e(URL::asset('assets/switcher/css/switcher.css')); ?>" rel="stylesheet" id="switcher-css" type="text/css" media="all"/>
		<link  href="<?php echo e(URL::asset('assets/plugins/date-picker/date-picker.css')); ?>" rel="stylesheet" id="switcher-css" type="text/css" media="all"/>

		<!-- Skin css-->
	<!--	<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(URL::asset('assets/skins/hor-skin/skin.css')); ?>" />-->
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(URL::asset('assets/skins/hor-skin/hor-skin2.css')); ?>" />
		<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(URL::asset('assets/skins/hor-skin/main2.css')); ?>" />

		<link rel="stylesheet" href="<?php echo e(URL::asset('assets/skins/demo.css')); ?>"/>
	</head>

	<body class="app">

		<div class="page">
			<div class="page-main">


				<div class="app-content">
					<div class="container">
						<div class="row">
							<div class="col-md-12">

								<div class="card" style="margin-top:30px;">
									<div class="card-header">
                    <div class="col-md-5">
                      <img src="<?php echo asset(app_config('AppLogo')); ?>" class="header-brand-img desktop-lgo" alt="<?php echo app_config('AppName') ?>">
                  </div>
                    <div class="col-md-6">
                      <h4>
                    <?php echo app_config('AppName') ?></h4>
                  </div>
									</div>
									<div class="card-body">
                  <div class="row col-md-12">
                    <div class="col-md-8">
											<h4 class="mb-1">Hi <strong><?php echo $form_date[0]->name."(".$form_date[0]->email .")"; ?></strong>,</h4>
											This is the receipt for a payment of <strong><?php echo $pay_info[0]->orgTxnAmount; ?></strong> (INR) for your Application Fee
										</div>
                    <div class="col-md-4" style="text-align:end;">
                      <span>Payment Status : </span>
                      <strong><?php echo $pay_info[0]->pgRespCode=="000" ? "<span style='color: red;
    font-weight: 400;'>Success</span>" : "<span style='color: green;
font-weight: 400;'>Failed</span>"; ?></strong>
                    </div>
                  </div>

										<div class="card-body pl-0 pr-0">
											<div class="row">
												<div class="col-sm-6">
													<span>Payment No.</span><br>
													<strong><?php echo $pay_info[0]->PGTxnNo; ?></strong>
												</div>
												<div class="col-sm-6 text-right">
													<span>Payment Date</span><br>
													<strong><?php echo $pay_info[0]->created_date  ; ?></strong>
												</div>
											</div>
										</div>
										<div class="dropdown-divider"></div>
										<div class="row pt-4">
	                 <div class="table-responsive push">
                      <table class="table table-bordered table-hover">
                        <thead>
                          <tr>
                            <th></th>
                            <th class="text-center">Subject Type</th>
                            <th class="text-center">Subject Name</th>
                          </tr>
                        </thead>
                          <tbody>
                            <?php $i=0; ?>
                            <?php $__currentLoopData = $form_date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                              <td class="text-center"><?php echo e($i); ?></td>
                              <td class="text-center"><?php echo e($value->sub_type); ?></td>
                              <td class="text-center"><?php echo e($value->sub_name); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                    </div>


										<div class="table-responsive push">



											<table class="table table-bordered table-hover">


												<tr>
													<td colspan="4" class="font-w600 text-right">Application Fee</td>
													<td class="text-right"><?php echo "INR ". $pay_info[0]->orgTxnAmount; ?></td>
												</tr>
												<tr>
													<td colspan="4" class="font-weight-bold text-uppercase text-right">Total</td>
													<td class="font-weight-bold text-right"><strong><?php echo "INR ". $pay_info[0]->orgTxnAmount; ?></strong></td>
												</tr>
                        <tr>
                      													<td colspan="5" class="text-right">
                      														<button type="button" class="btn btn-info" onClick="javascript:window.print();"><i class="si si-printer"></i> Print Invoice</button>
                      													</td>
                      												</tr>
											</table>
										</div>
										<p class="text-muted text-center">Thank you !</p>
									</div>
								</div>
							</div>
						</div>
						<!-- End row-->

					</div>
				</div><!-- end app-content-->
			</div>
			<!-- End Footer-->

		</div>

    <!-- Jquery js-->
    <script src="<?php echo e(URL::asset('assets/js/vendors/jquery-3.4.0.min.js')); ?>"></script>

    <!-- Bootstrap4 js-->
    <script src="<?php echo e(URL::asset('assets/plugins/bootstrap/popper.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!--Othercharts js-->
    <script src="<?php echo e(URL::asset('assets/plugins/othercharts/jquery.sparkline.min.js')); ?>"></script>

    <!-- Circle-progress js-->
    <script src="<?php echo e(URL::asset('assets/js/vendors/circle-progress.min.js')); ?>"></script>

    <!-- Jquery-rating js-->
    <script src="<?php echo e(URL::asset('assets/plugins/rating/jquery.rating-stars.js')); ?>"></script>

    <!--Horizontal js-->
    <script src="<?php echo e(URL::asset('assets/plugins/horizontal-menu/horizontal.js')); ?>"></script>

    <!-- P-scroll js-->
    <script src="<?php echo e(URL::asset('assets/plugins/p-scrollbar/p-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/p-scrollbar/p-scroll.js')); ?>"></script>
    <!-- Switcher js -->
    <script src="<?php echo e(URL::asset('assets/switcher/js/switcher.js')); ?>"></script>
  	<script src="<?php echo e(URL::asset('assets/plugins/date-picker/date-picker.js')); ?>"></script>
  	<script src="<?php echo e(URL::asset('assets/plugins/date-picker/jquery-ui.js')); ?>"></script>



	</body>
</html>
<?php /**PATH /var/www/vhosts/stpaulscollege.co.in/soft.stpaulscollege.co.in/resources/views/application/downloadForm.blade.php ENDPATH**/ ?>