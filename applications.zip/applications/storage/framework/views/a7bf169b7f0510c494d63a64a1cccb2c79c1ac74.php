
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/forn-wizard/css/forn-wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/formwizard/smart_wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::asset('assets/plugins/formwizard/smart_wizard_theme_dots.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-content page-body">
					<div class="container">

						<!--Page header-->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title">Dashboard</h4>
								<ol class="breadcrumb pl-0">
									<li class="breadcrumb-item"><a href="#">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Application Form</li>
								</ol>
							</div>

						</div>
						<!--End Page header-->

            <div class="row">
    							<div class="col-12">
    								<div class="card">
    									<div class="card-header">
    										<h3 class="card-title">Application Form</h3>
    									</div>
    									<div class="card-body">
    										<div id="smartwizard-3">
    											<ul>
    												<li><a href="#step-10">Application</a></li>
    												<li><a href="#step-11">Payment</a></li>
    											</ul>
    											<div>
    												<div id="step-10" >
    													<form id="applicationForm" name="applicationForm" enctype="multipart/form-data" method="post">
																<input type="hidden" id="sub_status" value="<?php echo $submitted; ?>"/>
    														<div class="form-group">
                                  	<label>I desire to join <span style="color:red;">*</span></label>
                                    <div style="display: flex;flex-wrap: nowrap;">
                                  <label class="custom-control custom-radio">
  															<input type="radio" class="custom-control-input" id="course" name="course" value="Arts" <?php if((isset($formData[0]->course)  ? $formData[0]->course : '') == 'Arts'): ?> { checked }  <?php endif; ?> required/>
  															<span class="custom-control-label">Arts</span>
  														</label>
                              <label class="custom-control custom-radio" style="margin-left: 25px;">
                            <input type="radio" class="custom-control-input" name="course" id="course" value="Science" <?php if((isset($formData[0]->course)  ? $formData[0]->course : '') == 'Science'): ?>) { checked }  <?php endif; ?> required/>
                            <span class="custom-control-label">Science</span>
                          </label>
                          <label class="custom-control custom-radio" style="margin-left: 25px;">
                        <input type="radio" class="custom-control-input" name="course" id="course" value="Commerce" <?php if((isset($formData[0]->course)  ? $formData[0]->course : '') == 'Commerce'): ?>) { checked }  <?php endif; ?> required/>
                        <span class="custom-control-label">Commerce</span>
                      </label>
                        </div>
                    						</div>
    														<div class="form-group">
    															<label>Name of the applicant <span style="color:red;">*</span></label>
    															<input type="text" onblur="myFunction()" class="form-control" name="name" value="<?php echo e(Auth::user()->name); ?>" id="name" placeholder="Name" readonly>
                              	</div>
                                <div class="form-group">
                                  <label>Name in Hindi  <span style="color:red;">*</span></label> <a id="t" onclick="myFunction()"  target="_blank" href="">(Translate)</a>
                                  <input type="text" class="form-control" name="name_hindi" value="<?php echo e(isset($formData[0]->name_hindi) ? $formData[0]->name_hindi : old('name_hindi')); ?>" id="name_hindi" placeholder="Name in hindi" required>
                                </div>
                                <div class="form-group">
    															<label>Date of Birth ( As recorded on Matriculation Record) <span style="color:red;">*</span></label>
																	<div class="input-group">
													<div class="input-group-prepend">
														<div class="input-group-text">
															<i class="fa fa-calendar tx-16 lh-0 op-6"></i>
														</div>
													</div><input class="form-control fc-datepicker" value="<?php echo e(isset($formData[0]->dob) ? $formData[0]->dob : old('dob')); ?>" id="dob" name="dob" data-date-format="DD-MM-YYYY" placeholder="DD-MM-YYYY" type="date" required>
												</div>
    														</div>
																<div class="form-group">
																	<label>Gender  <span style="color:red;">*</span></label>
																<div style="display: flex;flex-wrap: nowrap;">
																<label class="custom-control custom-radio">
																<input type="radio" <?php if((isset($formData[0]->gender)  ? $formData[0]->gender : '') == 'Male'): ?> { checked }) <?php endif; ?>  class="custom-control-input" id="gender" name="gender" value="Male"  required checked/>
																<span class="custom-control-label">Male</span>
																</label>
																<label class="custom-control custom-radio" style="margin-left: 25px;">
																<input type="radio" class="custom-control-input" name="gender" id="gender" value="Female" <?php if((isset($formData[0]->gender)  ? $formData[0]->gender : '') == 'Female'): ?> { checked } <?php endif; ?> required/>
																<span class="custom-control-label">Female</span>
																</label>

																</div>
																</div>

																<div class="form-group">
																	<label>State whether you belong to one of the following  <span style="color:red;">*</span></label>
																<div style="display: flex;flex-wrap: nowrap;">
																<label class="custom-control custom-radio">
																<input type="radio" class="custom-control-input cast" id="cast" name="cast" value="Schedule Tribe"  <?php if((isset($formData[0]->cast)  ? $formData[0]->cast : '') == 'Schedule Tribe'): ?> { checked } <?php endif; ?> required/>
																<span class="custom-control-label">Schedule Tribe</span>
																</label>
																<label class="custom-control custom-radio" style="margin-left: 25px;">
																<input type="radio" class="custom-control-input cast" id="cast" name="cast" value="Schedule Cast" <?php if((isset($formData[0]->cast)  ? $formData[0]->cast : '') == 'Schedule Cast'): ?> { checked } <?php endif; ?> required/>
																<span class="custom-control-label">Schedule Cast</span>
																</label>
																<label class="custom-control custom-radio" style="margin-left: 25px;">
																<input type="radio" class="custom-control-input cast" id="cast" name="cast" value="Other Backward Class" <?php if((isset($formData[0]->cast)  ? $formData[0]->cast : '') == 'Other Backward Class'): ?> { checked } <?php endif; ?> required/>
																<span class="custom-control-label">Other Backward Class </span>
																</label>
																<label class="custom-control" style="width: 10%;">
																	Sub-Caste :
																</label>
																<input style="width: 45%;" type="text" class="form-control" name="subcast" value="<?php echo e(isset($formData[0]->subcast) ? $formData[0]->subcast : old('subcast')); ?>"/>
																</div>
																</div>
																<div class="form-group" style="display: flex;">
																	<div class="col-md-6">
																	<label>Religion <span style="color:red;">*</span></label>
																	<input type="text" class="form-control" value="<?php echo e(isset($formData[0]->religion) ? $formData[0]->religion : old('religion')); ?>" name="religion" id="religion" placeholder="Religion" required>
																</div>
																	<div class="col-md-6">
																	<label>Denomination (If Christian)</label>
																	<input type="text" value="<?php echo e(isset($formData[0]->denomination) ? $formData[0]->denomination : old('denomination')); ?>" class="form-control" name="denomination" id="Denomination" placeholder="Denomination (If Christian)">
																</div>
															</div>
																<div class="form-group">
																	<label>Student Aadhar No. </label>
																	<input type="text" value="<?php echo e(isset($formData[0]->stu_aadhar) ? $formData[0]->stu_aadhar : old('stu_aadhar')); ?>" class="form-control" name="stu_aadhar" id="aadhar." placeholder="Student Aadhar No.">
															</div>

															<div class="form-group" style="display: flex;">
																<div class="col-md-6">
																<label>Father’s Name <span style="color:red;">*</span></label>
																<input type="text" value="<?php echo e(isset($formData[0]->f_name) ? $formData[0]->f_name : old('f_name')); ?>" class="form-control" name="f_name" id="f_name" placeholder="Father’s Name " required>
															</div>
																<div class="col-md-6">
																<label>Mother’s Name </label>
																<input type="text" value="<?php echo e(isset($formData[0]->m_name) ? $formData[0]->m_name : old('m_name')); ?>" class="form-control" name="m_name" id="m_name" placeholder="Mother’s Name ">
															</div>
														</div>
														<div class="form-group" style="display: flex;">
														<div class="col-md-6">
															<label>Guardian Name (If father is dead)</label>
															<input type="text" value="<?php echo e(isset($formData[0]->g_name) ? $formData[0]->g_name : old('g_name')); ?>" class="form-control" name="g_name" id="g_name" placeholder="Guardian Name (If father is dead)">
														</div>
														<div class="col-md-6">
															<label>Occupation of (Father / Mother / Guardian)</label>
															<input type="text" value="<?php echo e(isset($formData[0]->occupation) ? $formData[0]->occupation : old('occupation')); ?>" class="form-control" name="occupation" id="Occupation" placeholder="Occupation of (Father / Mother / Guardian)">
														</div>
													</div>
													<div class="form-group" style="display: flex;">
													<div class="col-md-6">
														<label>Present Address of Father / Guardians (Village / At) <span style="color:red;">*</span></label>
														<textarea class="form-control" name="present_address" id="present_address" placeholder="Present Address of Father / Guardians (Village / At)" required> <?php echo e(isset($formData[0]->present_address) ? $formData[0]->present_address : old('present_address')); ?></textarea>
													</div>
													<div class="col-md-6">
														<label>Permanent Address  Address of Father / Guardians (Village / At) <span style="color:red;">*</span></label>
														<textarea class="form-control" name="permanent_address" id="permanent_address" placeholder="Permanent Address of Father / Guardians (Village / At)" required> <?php echo e(isset($formData[0]->permanent_address) ? $formData[0]->permanent_address : old('permanent_address')); ?></textarea>
													</div>
												</div>
												<div class="form-group" style="display: flex;">
												<div class="col-md-6">
													<label>Phone No (Student) <span style="color:red;">*</span></label>
													<input type="number" class="form-control" value="<?php echo e(Auth::user()->mobile); ?>" name="s_phone_no" id="s_phone_no" placeholder="Phone No (Student)" readonly>
												</div>
												<div class="col-md-6">
													<label>Email-ID <span style="color:red;">*</span></label>
													<input type="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" name="email" id="email" placeholder="Email-ID" readonly>
												</div>
											</div>
											<div class="form-group" style="display: flex;">
											<div class="col-md-6">
												<label>Blood Group</label>
												<input type="text" value="<?php echo e(isset($formData[0]->blood_group) ? $formData[0]->blood_group : old('blood_group')); ?>" class="form-control" name="blood_group" id="blood_group" placeholder="Blood Group">
											</div>
											<div class="col-md-6">
												<label>Mark of Identification</label>
												<input type="text" class="form-control" value="<?php echo e(isset($formData[0]->identification_mark) ? $formData[0]->identification_mark : old('identification_mark')); ?>" name="identification_mark" id="identification_mark" placeholder="Mark of Identification">
											</div>
										</div>

										<div class="form-group">
											<label>Brother/Sister Studying in this College  </label>
										<div style="display: flex;flex-wrap: nowrap;">
										<label class="custom-control custom-radio">
										<input type="radio" class="custom-control-input" name="o_study" <?php if((isset($formData[0]->o_study)  ? $formData[0]->o_study : '') == 'Yes'): ?> { checked } <?php endif; ?>  value="Yes"/>
										<span class="custom-control-label">Yes</span>
										</label>
										<label class="custom-control custom-radio" style="margin-left: 25px;">
										<input type="radio" checked class="custom-control-input" name="o_study" <?php if((isset($formData[0]->o_study)  ? $formData[0]->o_study : '') == 'No'): ?> { checked } <?php endif; ?> value="No"/>
										<span class="custom-control-label">No</span>
										</label>
										</div>
										</div>
										<label>If yes kindly provide the following details</label>

										<div class="form-group" style="display: flex;">
										<div class="col-md-5">
											<label>Name</label>
											<input type="text" value="<?php echo e(isset($formData[0]->o_name) ? $formData[0]->o_name : old('o_name')); ?>" class="form-control" name="o_name" id="o_Name" placeholder="Name">
										</div>
										<div class="col-md-4">
											<label>Course & Session</label>
											<input type="text" value="<?php echo e(isset($formData[0]->course_session) ? $formData[0]->course_session : old('course_session')); ?>" class="form-control" name="course_session" id="Course_Session" placeholder="Course & Session">
										</div>
										<div class="col-md-3">
											<label>Mobile No</label>
											<input type="number" value="<?php echo e(isset($formData[0]->o_mobile) ? $formData[0]->o_mobile : old('o_mobile')); ?>" class="form-control" value="" name="o_mobile" id="Mobile_No" placeholder="Mobile No">
										</div>
										</div>
<div class="form-group" id="subs">
	<?php if( empty($subjects || $subjects->isEmpty()) || count($subjects)==0) { ?>
	<table class="table card-table table-vcenter  table-warning">
		<thead>
			<tr>
				<th>Subject</th>
				<th class="arts">Arts</th>
				<th class="commerce">Commerce</th>
				<th class="science">Science</th>
			</tr>
		</thead>
	<tbody>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="form-control" readonly/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
		</tr>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="form-control" readonly/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="NA" class="form-control" readonly/></td>
			<td><input type="text" value="NA" class="form-control" readonly/></td>
		</tr>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="form-control" readonly/> </td>
			<td><input type="text" value="NA" class="form-control" readonly/></td>
			<td><input type="text" value="Accountancy (ACT)" class="form-control" readonly/></td>
			<td><input type="text" value="Physics (PHY)" class="form-control" readonly/></td>
		</tr>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="form-control" readonly/> </td>
			<td><input type="text" value="NA" class="form-control"/></td>
			<td><input type="text" value="Business Studies (BST)" class="form-control" readonly/></td>
			<td><input type="text" value="Chemistry (CHE)" class="form-control" readonly/></td>
		</tr>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="form-control" readonly/> </td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
		</tr>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="form-control" readonly/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
		</tr>
		<tr>
			<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="form-control" readonly/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="NA" class="form-control" readonly/></td>
			<td><input type="text" value="NA" class="form-control" readonly/></td>
		</tr>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="form-control" readonly/> </td>
			<td><input type="text" value="" name="sub_art" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
			<td><input type="text" value="" class="form-control"/></td>
		</tr>
</tbody>
	</table>

<?php }else { ?>

	<table id="example" class="table card-table table-vcenter  table-warning">
		<thead>
			<tr>
				<th>Subject</th>
				<th class="arts"><?php echo e(isset($formData[0]->course) ? $formData[0]->course : ''); ?></th>
				</tr>
		</thead>
	<tbody>
		<?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="<?php echo e(isset($value->sub_type) ? $value->sub_type : ''); ?>" class="form-control sub_type" readonly/></td>
			<td><input type="text" value="<?php echo e(isset($value->sub_name) ? $value->sub_name : ''); ?>" name="subject" class="form-control subject"/></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>


<?php } ?>
</div>
<div class="form-group">
	<label>I have Passed the Matriculation Examination (or Equivalent) :</label>
</div>
<div class="form-group" style="display:flex;">
	<div class="col-md-5">
	<label>From (School) </label>
	<input type="text" class="form-control" value="<?php echo e(isset($formData[0]->from_school) ? $formData[0]->from_school : old('from_school')); ?>" name="from_school" value="" id="School" placeholder="From (School)">
</div>
<div class="col-md-2">
<label>Total Marks Obtained  </label>
<input type="text" class="form-control" value="<?php echo e(isset($formData[0]->tmo) ? $formData[0]->tmo : old('tmo')); ?>" name="tmo" value="" id="tmo" placeholder="Total Marks Obtained">
</div>
<div class="col-md-2">
<label>Max Marks</label>
<input type="text" class="form-control"  value="<?php echo e(isset($formData[0]->max_marks) ? $formData[0]->max_marks : old('max_marks')); ?>" name="max_marks" value="" id="max_marks" placeholder="Max Marks">
</div>
<div class="col-md-2">
<label>Percentage Secured</label>
<input type="text" class="form-control" name="percentage_secured"value="<?php echo e(isset($formData[0]->percentage_secured) ? $formData[0]->percentage_secured : old('percentage_secured')); ?>" id="percentage_secured" placeholder="Percentage Secured">
</div>
</div>
<div class="form-group">
	<label>Jharkhand Academic Council Registration No (If Any)  :</label>
	<input type="text" class="form-control" name="jac_reg_no" value="<?php echo e(isset($formData[0]->jac_reg_no) ? $formData[0]->jac_reg_no : old('jac_reg_no')); ?>" id="jac_reg_no" placeholder="JAC Registration No">
</div>
<div class="form-group">
	<label>If admitted, will reside <span style="color:red;">*</span></label>
<div style="display: flex;flex-wrap: nowrap;">
<label class="custom-control custom-radio">
<input type="radio" class="custom-control-input" name="reside_with" id="reside_with" value="With Parents or Natural Guardians" <?php if((isset($formData[0]->reside_with)  ? $formData[0]->reside_with : '') == 'With Parents or Natural Guardians'): ?> { checked } <?php endif; ?> required/>
<span class="custom-control-label">With Parents or Natural Guardians </span>
</label>
<label class="custom-control custom-radio" style="margin-left: 25px;">
<input type="radio" class="custom-control-input" name="reside_with" id="reside_with" value="With Recognized Local Guardian" <?php if((isset($formData[0]->reside_with)  ? $formData[0]->reside_with : '') == 'With Recognized Local Guardian'): ?> { checked } <?php endif; ?> required/>
<span class="custom-control-label">With Recognized Local Guardian </span>
</label>
</div>
</div>
<div class="form-group" style="text-align: center;text-decoration: underline;">
	<b>PLEDGE :</b>
</div>
<div class="form-group">
	<b>Knowing that the aim of St. Paul’s College is character building with physical, mental development of student focusing on their physical education and cultural orientation.
Knowing that the religious feeling of  all students and their freedom of conscience will be respected in St. Paul’s College, Ranchi. Which is minority institution established and administered by the Diocese of Chotanagpur (CNI) Ranchi.
Knowing also that this institution aims at motivating students for service with Missionary Zeal and helping them to cultivate gentlemanly manners and habits of systematic work with a sense of vacation. </b>
</div>

<div class="form-group" style="display:flex;">
	<b>I </b><div class="col-md-3"> <input id="pname" type="text" class="form-control" name="" value="<?php echo e(Auth::user()->name); ?>" readonly/></div>
	<b>hereby pledge myself in any activities that will go against the interest of the College in general and against my own interest in particular.
		Failing which will be subject to any disciplinary action deemed and  proper by the College Authorities.</b>
	</div>
	<div class="form-group">
		<label><b>Note :</b></label>
		<ul style="list-style: inside;">
			<li>
					No application will be considered unless all particulars asked for are furnished and the required documents submitted.
			</li>
			<li>
					Admission once taken, no transfer certificate is allowed between the session, if college leaving Certificate is necessary required the whole session fee will be charged.
			</li>
		</ul>
</div>
<div class="form-group" style="display:flex;">
<div class="col-md-6">
	Date : <?php echo date('d-m-Y'); ?>
</div>
<div class="col-md-6">
</div>
</div>




									</form>

													</div>
    												<div id="step-11" class="">
    													<form method="post" action="<?php echo e(url('/application/paymentRequest')); ?>" >
																<div class="form-group">
																		<label><span style="color:red;">Payment Information : </span></label>
																		<p> Application Fee  <b><?php echo $pay_status=="0000" ? "Received." :"Not Received."; ?></b></p>
																	</div>
																<div class="row">
																<div class="col-md-12">
    														<div class="form-group">
    															<label>Name</label>
																	<input type="text" class="form-control" name="name" value="<?php echo e(Auth::user()->name); ?>" id="inputtext" readonly>
    														</div>
																<div class="form-group">
																	<label>Email</label>
																	<input type="text" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" id="inputtext" readonly>
																</div>
																<div class="form-group">
																	<label>Mobile</label>
																	<input type="text" class="form-control" name="mobile" value="<?php echo e(Auth::user()->mobile); ?>" id="inputtext" readonly>
																</div>
																<div class="form-group">
    															<label>Amount Payable : </label>
																	<span>INR <?php echo e(env('FEE')); ?></span>
    															<input type="hidden" id="pay_status" class="form-control" name="pay_status" value="<?php echo $pay_status ?>"  readonly>

    														</div>
																<div class="form-group">
																	<input type="submit" id="pay" class="btn btn-primary" name="Pay" value="Pay"/>
																</div>
															</div>
															</div>

    													</form>
    												</div>
    											</div>
    										</div>
    									</div>
    								</div>
    							</div>
    						</div>
				</div><!-- end app-content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script src="<?php echo e(URL::asset('assets/plugins/formwizard/jquery.smartWizard.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets/plugins/formwizard/fromwizard.js')); ?>"></script>
<script type="text/javascript">
function myFunction() {
	var name=document.getElementById('name').value;
	document.getElementById("pname").value=name;
	document.getElementById("t").href = "https://translate.google.co.in/?sl=en&tl=hi&text="+name+"&op=translate";
}
</script>
<script>
$(document).ready(function(){
	var pay_status=$("#pay_status").val();
//	alert(pay_status);
	if(pay_status=="0000"){
		$("#pay").prop("disabled", true);
	}
	var sub_status=$("#sub_status").val();
	if(sub_status==1){
		$("#applicationForm input").prop("disabled", true);
	}

	$("input[name='course']").change(function() {
	//	alert();
  //  var index = $(this).attr('name').substr(2);
		var classname=this.value;

		if(classname=='Commerce'){
				$("#subs").empty();
				$("#subs").append('<table id="example" class="table card-table table-vcenter  table-warning">\
				<thead>\
				<tr>\
					<th>Subject</th>\
					<th class="Commerce">Commerce</th>\
				</tr>\
			</thead>\
			<tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr></tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Accountancy (ACT)" class="subject form-control" readonly/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Business Studies (BST)" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="" class="subject form-control"/></td>\
			</tr>\
			</table>');
			}

		if(classname=='Science'){
				$("#subs").empty();
				$("#subs").append('<table id="example"  class="table card-table table-vcenter  table-warning">\
				<thead>\
				<tr>\
					<th>Subject</th>\
					<th class="Science">Science</th>\
				</tr>\
			</thead>\
			<tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr></tbody>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Physics (PHY)" class="subject form-control" readonly/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" name="subject" value="Chemistry (CHE)" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="sub_type form-control" readonly/> </td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="sub_type form-control" readonly/></td>\
				<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
			</tr>\
			<tr>\
				<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="sub_type form-control" readonly/> </td>\
				<td><input type="text"  name="subject" value="" class="subject form-control"/></td>\
			</tr>\
			</table>');
			}

	if(classname=='Arts'){
			$("#subs").empty();
			$("#subs").append('<table id="example"  class="table card-table table-vcenter  table-warning">\
			<thead>\
			<tr>\
				<th>Subject</th>\
				<th class="arts">Arts</th>\
			</tr>\
		</thead>\
		<tbody>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Core" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr></tbody>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Elective" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-1" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" value="NA" name="subject" class="subject form-control" readonly/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Compulsory-2" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" value="NA" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 1" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 2" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td> <input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Optional – 3" class="sub_type form-control" readonly/></td>\
			<td><input type="text" value="" name="subject" class="subject form-control"/></td>\
		</tr>\
		<tr>\
			<td><input style="background: transparent;border: navajowhite;" name="sub_type" type="text" value="Additional" class="sub_type form-control" readonly/> </td>\
			<td><input type="text" name="subject" value="" class="subject form-control"/></td>\
		</tr>\
		</table>');
		}
});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/stpaulscollege.co.in/soft.stpaulscollege.co.in/resources/views/application/application.blade.php ENDPATH**/ ?>