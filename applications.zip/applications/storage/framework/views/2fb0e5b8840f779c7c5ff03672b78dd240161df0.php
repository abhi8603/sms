<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style>
center{
    position: absolute;
    top: 50%;
    left: 50%;
    margin-right: -50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body>

<div class="container center" style="display: contents;">
    <h2 style="text-align: center;">Registration form</h2>
  <div style="border: 1px solid #cccc;
    padding: 10px;" class="col-md-6 offset-3">

  <form action="">
    <div class="form-group">
      <label for="email">Name:</label>
      <input type="text" class="form-control" id="Name" placeholder="Enter Name" name="name" required="required"/>
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required="required">
    </div>
     <div class="form-group">
      <label for="email">Mobile:</label>
      <input type="text" class="form-control" id="number" onkeypress="return isMobileNo(event)" placeholder="Enter Mobile Number" name="email" required="required"/>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required="required"/>
    </div>
    <div class="form-group">
      <label for="pwd">Confirm Password:</label>
      <input type="password" class="form-control" id="cpwd" placeholder="Enter password" name="pswd" required="required"/>
    </div>
   
    <button type="submit" id="save" class="btn btn-primary">Save</button>
  </form><br>
  <a class="" href="<?php echo e(url('/')); ?>">Already have account ? <span>Login</span></a>
</div>
</div>
</body>
<script>
function isMobileNo(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

 $(document).ready(function(){
$("#save").on("click",function(e){
  e.preventDefault();
  var p = $('#pwd').val();
  var cp = $('#cpwd').val();
  if(p!=cp){
    alert("Password Not Matched");
    return
  }
        errors = [];
    if (p.length < 8) {
        errors.push("Your password must be at least 8 characters");
    }
    if (p.search(/[a-z]/i) < 0) {
        errors.push("Your password must contain at least one letter."); 
    }
    if (p.search(/[0-9]/) < 0) {
        errors.push("Your password must contain at least one digit.");
    }
    if (p.search(/[A-Z]/) < 0) {
        errors.push("Your password must contain at least one upper case letter.");
    }
    if (p.search(/[@!#$%&?]/i) < 0) {
        errors.push("Your password must contain at least one Special characters.");
    }
    if (errors.length > 0) {
        alert(errors.join("\n"));
        return false;
    }
})
 })
  </script>
</html>
<?php /**PATH C:\xampp\htdocs\test\resources\views/register.blade.php ENDPATH**/ ?>