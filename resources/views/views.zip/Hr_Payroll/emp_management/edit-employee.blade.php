@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/responsive.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/select2/dist/css/select2.min.css') }}">

@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"><i class="fa fa-dashboard"></i> HR/Payroll </a></li>
        <li><a href="#"><i class="fa fa-dashboard"></i> Employee Management  </a></li>
        <li class="active">Add Employee</li>
      </ol>
    </section>

    <!-- Main content -->
      <section class="content">
          @include('notification.notify')
    <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Employee Registration</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              @foreach($emplist as $emplist)
              <div class="row">
                <div class="col-md-12">

                  <!-- /.form-group -->
                  <div class="box box-primary">

                           <!-- /.box-header -->
                           <!-- form start -->
                           <form role="form" method="post" enctype="multipart/form-data" action="{{url('hr/employee/update')}}">
                             <div class="box-header with-border">
                               <h3 class="box-title">Employee Details</h3>
                             </div>
                             <div class="box-body">
              <div class="row">
                <div class="form-group col-md-4">
                 <label for="exampleInputEmail1">Employee Code<span style="color:red;"> *</span></label>
                 <input type="text" class="form-control" id="empcode" value="{{$emplist->empcode}}" readonly name="empcode" placeholder="Employee Code">
               </div>
               <div class="form-group col-md-4">
                               <label>Joining Date</label>
                               <div class="input-group date">
                                 <div class="input-group-addon">
                                   <i class="fa fa-calendar"></i>
                                 </div>
                                 <input type="text" class="form-control pull-right" value="{{ old('joiningdate') }} OR {{$emplist->joiningdate}}" id="startdate" name="joiningdate">
                               </div>
                               <!-- /.input group -->
                             </div>
               <div class="form-group col-md-4">
                 <label for="exampleInputEmail1">Department<span style="color:red;"> *</span></label>
                 <select class="form-control select2" name="department" style="width: 100%;" required>
                     <option value="" selected="selected">Please select</option>
                     @foreach($department as $department)
                     <option value="{{$department->department_name}}" @if($emplist->department== $department->department_name) selected @endif>{{$department->department_name}}</option>
                     @endforeach

              </select>
            </div>

                  <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Designation<span style="color:red;"> *</span></label>
                    <select class="form-control select2" name="designation" style="width: 100%;" required>
                        <option value="" selected="selected">Please select</option>
                        @foreach($designation as $designation)
                        <option value="{{$designation->degination}}" @if($emplist->designation== $designation->degination) selected @endif>{{$designation->degination}}</option>
                        @endforeach
                 </select>
               </div>

                  <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Qualification<span style="color:red;"> *</span></label>
                    <input type="text" class="form-control" id="qualification" value="{{$emplist->qualification}}" name="qualification" placeholder="Qualification" required>
                  </div>
                  <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Total Experience<span style="color:red;"> *</span></label>
                    <input type="text" class="form-control" id="totalexperience" value="{{$emplist->tot_exp}}" name="totalexperience" placeholder="Total Experience" required>
                  </div>

                  <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">User Type<span style="color:red;"> *</span></label>
                    <select class="form-control select2" name="usertype" style="width: 100%;" required>
                        <option value="" selected="selected">Please select</option>
                        @foreach($userList as $userList)
                        <option value="{{$userList->usertype}}" @if($emplist->user_type== $userList->usertype) selected @endif>{{$userList->usertype}}</option>
                        @endforeach
                 </select>
               </div>

              </div>
              <div class="box-header box box-primary with-border">
                <h3 class="box-title">PERSONAL DETAILS:-</h3>
              </div>
              <div class="row">
                <div class="form-group col-md-4">
                  <label for="exampleInputEmail1">First Name<span style="color:red;"> *</span></label>
                  <input type="text" class="form-control" id="fname" value="{{$emplist->fname}}" name="fname" placeholder="First Name" required>
                </div>
                <div class="form-group col-md-4">
                  <label for="exampleInputEmail1">Middle Name</label>
                  <input type="text" class="form-control" id="mname" value="{{$emplist->mname}}" name="mname" placeholder="Middle Name">
                </div>
                <div class="form-group col-md-4">
                  <label for="exampleInputEmail1">Last Name<span style="color:red;"> *</span></label>
                  <input type="text" class="form-control" id="lname" value="{{$emplist->lname}}" name="lname" placeholder="Last Name" required>
                </div>
                <div class="form-group col-md-4">
                                <label>Date of Birth</label>
                                <div class="input-group date">
                                  <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                  </div>
                                  <input type="text" class="form-control pull-right" value="{{$emplist->dob}}" id="dob" name="dob" required>
                                </div>
                                <!-- /.input group -->
                              </div>

                  <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Gender<span style="color:red;"> *</span></label>
                    <select class="form-control select2" name="gender" style="width: 100%;" required>
                        <option value="">Please select</option>
                        <option value="Male" @if($emplist->gender== 'Male') selected @endif>Male</option>
                        <option value="Female" @if($emplist->gender== 'Female') selected @endif>Female </option>
                 </select>
               </div>
               <div class="form-group col-md-4">
                 <label for="exampleInputEmail1">PAN Number</label>
                 <input type="text" class="form-control" id="InstitutionName" value="{{$emplist->pan_no}}" name="panno" placeholder="PAN Number">
               </div>


            <div class="form-group col-md-4">
              <label for="exampleInputEmail1">PF Number</label>
              <input type="text" class="form-control" id="InstitutionName" value="{{$emplist->pf_no}}" name="pf" placeholder="PF Number">
            </div>
            <div class="form-group col-md-4">
              <label for="exampleInputEmail1">ESI</label>
              <input type="text" class="form-control" id="InstitutionName" value="{{$emplist->esi}}" name="esi" placeholder="ESI">
            </div>
            <div class="form-group col-md-4">
              <label for="exampleInputEmail1">Nationality<span style="color:red;"> *</span></label>
              <select class="form-control select2" name="nationality" style="width: 100%;">
                  <option value="">Please select</option>
                  <option value="Indian" selected="selected" @if($emplist->nationality== 'Indian') selected @endif>Indian</option>
                  <option value="Other" @if($emplist->nationality== 'Other') selected @endif>Other</option>
           </select>
         </div>
         <div class="form-group col-md-4">
           <label for="exampleInputEmail1">Category<span style="color:red;"> *</span></label>
           <select class="form-control select2" name="category" style="width: 100%;">
               <option value="" selected="selected">Please select</option>
               @foreach($category as $category)
               <option value="{{$category->stu_category}}" @if($emplist->category== $category->stu_category) selected @endif >{{$category->stu_category}}</option>
              @endforeach
        </select>
      </div>
      <div class="form-group col-md-4">
        <label for="exampleInputEmail1">Religion<span style="color:red;"> *</span></label>
        <select class="form-control select2" name="religion" style="width: 100%;">
            <option>Please Religion</option>
            <option value="Hindu" @if($emplist->religion== "Hindi") selected @endif >Hindu</option>
            <option value="Muslim" @if($emplist->religion== "Muslim") selected @endif>Muslim</option>
            <option value="Sikh" @if($emplist->religion== "Sikh") selected @endif>Sikh</option>
            <option value="Christianity" @if($emplist->religion== "Christianity") selected @endif>Christianity</option>
            <option value="Buddhism" @if($emplist->religion== "Buddhism") selected @endif>Buddhism</option>
     </select>
   </div>
   <div class="form-group col-md-4">
     <label for="exampleInputEmail1">Aadhar Number</label>
     <input type="text" class="form-control" id="Aadharno" name="aadharno"  value="{{$emplist->aadhar_number}}"  placeholder="Aadhar Number">
   </div>
     </div>
              </div>
              <div class="box-header with-border">
                <h3 class="box-title">CONTACT DETAILS:-</h3>
              </div>
              <div class="box-body">
<div class="row">
  <div class="form-group col-md-5">
    <label for="exampleInputPassword1">Permanent Address<span style="color:red;"> *</span></label>
    <textarea class="form-control" id="permanentaddress" rows="3" name="permanentsddress" placeholder="Permanent Address" required>{{$emplist->permanent_address}}</textarea>
  </div>
    <div class="form-group col-md-2">
    <br><be>  <div class="checkbox">
          <label>
            <input type="checkbox" id="same">
                    </label>
                    <br>  <p>  same as Permanent Address</p>
                  </div>
    </div>
  <div class="form-group col-md-5">
    <label for="exampleInputPassword1">Present Address<span style="color:red;"> *</span></label>
    <textarea class="form-control" rows="3" id="presentaddress" name="persentddress" placeholder="Present Address" required>{{$emplist->present_address}}</textarea>
  </div>
<div class="form-group col-md-4">
  <label for="exampleInputEmail1">City<span style="color:red;"> *</span></label>
  <input type="text" class="form-control" id="city" name="city" value="{{$emplist->city}}"  placeholder="City" required>
</div>
<div class="form-group col-md-4">
  <label for="exampleInputEmail1">Pin<span style="color:red;"> *</span></label>
  <input type="text" class="form-control" id="Pin" placeholder="Pin" name="pin" value="{{$emplist->pin}}"  onkeypress="return isNumber(event)"  required>
</div>

   <div class="form-group col-md-4">
     <label for="exampleInputEmail1">Country<span style="color:red;"> *</span></label>
     <select class="form-control select2" name="country" style="width: 100%;" required>
         <option value="">Please select</option>
         <option value="India" selected="selected" @if($emplist->country== "India") selected @endif>India</option>
         <option value="Other" @if($emplist->country== "Other") selected @endif>Other </option>
  </select>
</div>

<div class="form-group col-md-4">
  <label for="exampleInputEmail1">State<span style="color:red;"> *</span></label>

  <input type="text" class="form-control" id="state" value="{{$emplist->state}}"  name="state" placeholder="State" required>
</div>
<div class="form-group col-md-4">
  <label for="exampleInputEmail1">Phone<span style="color:red;"> *</span></label>
  <input type="text" class="form-control" id="Pin" placeholder="Phone" value="{{$emplist->phone}}"  name="phone" onkeypress="return isNumber(event)"  required>
</div>
<div class="form-group col-md-4">
  <label for="exampleInputEmail1">Email<span style="color:red;"> *</span></label>
  <input type="email" class="form-control" id="Pin" placeholder="Email" value="{{$emplist->email}}"  name="email" required>
</div>
</div>
  </div>
</div>
  </div>

          </div>
         <div class="box-footer">
       <button type="submit" class="btn btn-primary">Update</button>
     </div>
     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   </form>
   @endforeach
   </div>

                </div>

              </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')
<script src="{{ URL::asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/select2/dist/js/select2.full.min.js') }}"></script>

<script>
$("#same").change(function() {
    if(this.checked) {
      $('#presentaddress').val($('#permanentaddress').val());
    }else{
  $('#presentaddress').val("");
    }
});
</script>

<script>
$(document).ready(function() {
   $.extend($.fn.dataTable.defaults, {
 dom: 'Bfrtip'
});
   $('#example').DataTable( {

       buttons: [
           'copy', 'csv', 'excel', 'pdf', 'print'
       ],
         rowReorder: {
           selector: 'td:nth-child(2)'
       },
       responsive: true


   } );
   } );

</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2();
    $('#startdate').datepicker({
      autoclose: true,
      format:'dd-mm-yyyy'
    });
    $('#dob').datepicker({
      autoclose: true,
      format:'dd-mm-yyyy'
    });

    //Datemask dd/mm/yyyy

  });
</script>
<script>
$("#totalexperience").keyup(function() {
    var $this = $(this);
    $this.val($this.val().replace(/[^\d.]/g, ''));
});
</script>
<script>

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
<script>
  // This example displays an address form, using the autocomplete feature
  // of the Google Places API to help users fill in the information.

  // This example requires the Places library. Include the libraries=places
  // parameter when you first load the API. For example:
  // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

  var placeSearch, autocomplete;
  var componentForm = {
    street_number: 'short_name',
    route: 'long_name',
    locality: 'long_name',
    administrative_area_level_1: 'short_name',
    country: 'long_name',
    postal_code: 'short_name'
  };

  function initAutocomplete() {
    // Create the autocomplete object, restricting the search to geographical
    // location types.

        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('state')),
            {types: ['geocode']});
    // When the user selects an address from the dropdown, populate the address
    // fields in the form.
    autocomplete.addListener('place_changed', fillInAddress);
  }

  function fillInAddress() {
    // Get the place details from the autocomplete object.
    var place = autocomplete.getPlace();

    for (var component in componentForm) {
      document.getElementById(component).value = '';
      document.getElementById(component).disabled = false;
    }

    // Get each component of the address from the place details
    // and fill the corresponding field on the form.
    for (var i = 0; i < place.address_components.length; i++) {
      var addressType = place.address_components[i].types[0];
      if (componentForm[addressType]) {
        var val = place.address_components[i][componentForm[addressType]];
        document.getElementById(addressType).value = val;
      }
    }
  }

  // Bias the autocomplete object to the user's geographical location,
  // as supplied by the browser's 'navigator.geolocation' object.
  function geolocate() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function(position) {
        var geolocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        var circle = new google.maps.Circle({
          center: geolocation,
          radius: position.coords.accuracy
        });
        autocomplete.setBounds(circle.getBounds());
      });
    }
  }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAMtsOugMpddkKZ8tx9hPxmwIdGKjAONLo&libraries=places&callback=initAutocomplete" async defer></script>
@endsection
<!-- ./wrapper -->
