@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/responsive.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/select2/dist/css/select2.min.css') }}">

@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"><i class="fa fa-dashboard"></i>Hr</a></li>
        <li class="active">Set Roles</li>
      </ol>
    </section>
    <section class="content">
        @include('notification.notify')
  <div class="box box-default">
    <!-- Main content -->
    <div class="box-header with-border">
      <h3 class="box-title">Set Roles</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
      </div>
    </div>

        <div class="row">
          <div class="col-md-12">
            <form class="" role="form" action="{{url('hr/employee/update-employee-set-roles')}}" method="post">
          <div class="row">
              <div class="col-lg-12">
                  <div class="panel">
                      <div class="panel-body">
                              <div class="panel-heading">
                                  <h3 class="panel-title"> Settings</h3>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">

                                      <input type="checkbox" @if(permission($emp_roles->id,1)) checked @endif name="perms[]" value="1">
                                      <span class="co-check-ui"></span>
                                      <label>Dashboard</label>
                                  </div>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">
                                      <input type="checkbox"  @if(permission($emp_roles->id,4)) checked @endif name="perms[]" value="4">
                                      <span class="co-check-ui"></span>
                                      <label>Academic Details</label>
                                  </div>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">
                                      <input type="checkbox"  @if(permission($emp_roles->id,5)) checked @endif name="perms[]" value="5">
                                      <span class="co-check-ui"></span>
                                      <label>Create Institution</label>
                                  </div>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">
                                      <input type="checkbox"  @if(permission($emp_roles->id,6)) checked @endif name="perms[]" value="6">
                                      <span class="co-check-ui"></span>
                                      <label>Student Import</label>
                                  </div>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">
                                      <input type="checkbox"  @if(permission($emp_roles->id,7)) checked @endif name="perms[]" value="7">
                                      <span class="co-check-ui"></span>
                                      <label>Employee Import</label>
                                  </div>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">
                                      <input type="checkbox"  @if(permission($emp_roles->id,8)) checked @endif name="perms[]" value="8">
                                      <span class="co-check-ui"></span>
                                      <label>Employee Applicants</label>
                                  </div>
                              </div>
                              <div class="form-group col-md-3">
                                  <div class="coder-checkbox">
                                      <input type="checkbox"  @if(permission($emp_roles->id,9)) checked @endif name="perms[]" value="9">
                                      <span class="co-check-ui"></span>
                                      <label>Application List</label>
                                  </div>
                              </div>
                              </div>
                              </div>
                              <div class="panel">
                                  <div class="panel-body">
                                          <div class="panel-heading">
                                              <h3 class="panel-title"> Acadmics</h3>
                                          </div>

                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,10)) checked @endif name="perms[]" value="10">
                                                  <span class="co-check-ui"></span>
                                                  <label>Course</label>
                                              </div>
                                          </div>
                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,11)) checked @endif name="perms[]" value="11">
                                                  <span class="co-check-ui"></span>
                                                  <label>Batch</label>
                                              </div>
                                          </div>
                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,12)) checked @endif name="perms[]" value="12">
                                                  <span class="co-check-ui"></span>
                                                  <label>Class Teacher Allocation</label>
                                              </div>
                                          </div>
                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,13)) checked @endif name="perms[]" value="13">
                                                  <span class="co-check-ui"></span>
                                                  <label>Subjects</label>
                                              </div>
                                          </div>
                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                                                  <span class="co-check-ui"></span>
                                                  <label>Subject Assign</label>
                                              </div>
                                          </div>
                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                                                  <span class="co-check-ui"></span>
                                                  <label>Subject Allocation</label>
                                              </div>
                                          </div>
                                          <div class="form-group col-md-3">
                                              <div class="coder-checkbox">
                                                  <input type="checkbox"  @if(permission($emp_roles->id,15)) checked @endif name="perms[]" value="15">
                                                  <span class="co-check-ui"></span>
                                                  <label>Import Subject Allocation</label>
                                              </div>
                                          </div>
                                        </div>
                                      </div>
                                          <div class="panel">
                                              <div class="panel-body">
                                                      <div class="panel-heading">
                                                          <h3 class="panel-title"> HR/Payroll</h3>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,2)) checked @endif name="perms[]" value="2">
                                                              <span class="co-check-ui"></span>
                                                              <label>Departments</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,3)) checked @endif name="perms[]" value="3">
                                                              <span class="co-check-ui"></span>
                                                              <label>Designations</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,16)) checked @endif name="perms[]" value="16">
                                                              <span class="co-check-ui"></span>
                                                              <label>Employees</label>
                                                          </div>
                                                      </div>

                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,17)) checked @endif name="perms[]" value="17">
                                                              <span class="co-check-ui"></span>
                                                              <label>Add Employee</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,18)) checked @endif name="perms[]" value="18">
                                                              <span class="co-check-ui"></span>
                                                              <label>Employee List</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,19)) checked @endif name="perms[]" value="19">
                                                              <span class="co-check-ui"></span>
                                                              <label>Update Employee</label>
                                                          </div>
                                                      </div>


                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,20)) checked @endif name="perms[]" value="20">
                                                              <span class="co-check-ui"></span>
                                                              <label>Delete Employee</label>
                                                          </div>
                                                      </div>


                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,21)) checked @endif name="perms[]" value="21">
                                                              <span class="co-check-ui"></span>
                                                              <label>User Type</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,22)) checked @endif name="perms[]" value="22">
                                                              <span class="co-check-ui"></span>
                                                              <label>Add User Type</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,59)) checked @endif name="perms[]" value="59">
                                                              <span class="co-check-ui"></span>
                                                              <label>Set User Role</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,23)) checked @endif name="perms[]" value="23">
                                                              <span class="co-check-ui"></span>
                                                              <label>Add Employees Bank details</label>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-3">
                                                          <div class="coder-checkbox">
                                                              <input type="checkbox"  @if(permission($emp_roles->id,24)) checked @endif name="perms[]" value="24">
                                                              <span class="co-check-ui"></span>
                                                              <label>Employee Attendance Import</label>
                                                          </div>
                                                      </div>
                                                    </div>
                                                  </div>
                                                  <div class="panel">
                                                      <div class="panel-body">
                                                              <div class="panel-heading">
                                                                  <h3 class="panel-title"> Student</h3>
                                                              </div>

                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,25)) checked @endif name="perms[]" value="25">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Student Category</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,26)) checked @endif name="perms[]" value="26">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Student Admission</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,61)) checked @endif name="perms[]" value="61">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>View Student</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,62)) checked @endif name="perms[]" value="62">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Update Student</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,60)) checked @endif name="perms[]" value="60">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Delete Student</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,27)) checked @endif name="perms[]" value="27">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Student List</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,28)) checked @endif name="perms[]" value="28">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Attendence</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,29)) checked @endif name="perms[]" value="29">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Tranport Allocation</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,30)) checked @endif name="perms[]" value="30">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Hostel Allocation</label>
                                                                  </div>
                                                              </div>
                                                              <div class="form-group col-md-3">
                                                                  <div class="coder-checkbox">
                                                                      <input type="checkbox"  @if(permission($emp_roles->id,31)) checked @endif name="perms[]" value="31">
                                                                      <span class="co-check-ui"></span>
                                                                      <label>Gaurdian List</label>
                                                                  </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <div class="panel">
                                                              <div class="panel-body">
                                                                      <div class="panel-heading">
                                                                          <h3 class="panel-title"> Finance</h3>
                                                                      </div>

                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,32)) checked @endif name="perms[]" value="32">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee Category</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,33)) checked @endif name="perms[]" value="33">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee Subcategory</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,34)) checked @endif name="perms[]" value="34">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee SubCategory Fine</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,35)) checked @endif name="perms[]" value="35">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee Wavier</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,36)) checked @endif name="perms[]" value="36">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee template</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,37)) checked @endif name="perms[]" value="37">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee Allocation</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,38)) checked @endif name="perms[]" value="38">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Fee Report</label>
                                                                          </div>
                                                                      </div>
                                                                      <div class="form-group col-md-3">
                                                                          <div class="coder-checkbox">
                                                                              <input type="checkbox"  @if(permission($emp_roles->id,39)) checked @endif name="perms[]" value="39">
                                                                              <span class="co-check-ui"></span>
                                                                              <label>Import Fee</label>
                                                                          </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                  <div class="panel">
                                                                      <div class="panel-body">
                                                                              <div class="panel-heading">
                                                                                  <h3 class="panel-title"> Transport</h3>
                                                                              </div>

                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,40)) checked @endif name="perms[]" value="40">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Vechicle</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,41)) checked @endif name="perms[]" value="41">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Add Vechicle</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,42)) checked @endif name="perms[]" value="42">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Update Vechicle</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,43)) checked @endif name="perms[]" value="43">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Delete Vechicle</label>
                                                                                  </div>
                                                                              </div>

                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,44)) checked @endif name="perms[]" value="44">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Driver</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,45)) checked @endif name="perms[]" value="45">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Add Driver</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,46)) checked @endif name="perms[]" value="46">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Delete Driver</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,47)) checked @endif name="perms[]" value="47">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>View Driver</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,48)) checked @endif name="perms[]" value="48">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Update Driver</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,49)) checked @endif name="perms[]" value="49">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Route</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,50)) checked @endif name="perms[]" value="50">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Add Route</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,51)) checked @endif name="perms[]" value="51">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>View Route</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,52)) checked @endif name="perms[]" value="52">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Update Route</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,53)) checked @endif name="perms[]" value="53">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Delete Route</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,54)) checked @endif name="perms[]" value="54">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Destination</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,55)) checked @endif name="perms[]" value="55">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Add Destination</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,56)) checked @endif name="perms[]" value="56">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>View Destination</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,57)) checked @endif name="perms[]" value="57">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Update Destination</label>
                                                                                  </div>
                                                                              </div>
                                                                              <div class="form-group col-md-3">
                                                                                  <div class="coder-checkbox">
                                                                                      <input type="checkbox"  @if(permission($emp_roles->id,58)) checked @endif name="perms[]" value="58">
                                                                                      <span class="co-check-ui"></span>
                                                                                      <label>Delete Destination</label>
                                                                                  </div>
                                                                              </div>



                                                                            </div>
                                                                          </div>

                          <div class="panel">
                          <div class="panel-body">
                          <div class="panel-heading">
                          <h3 class="panel-title"> Hostel</h3>
                          </div>
                          <div class="form-group col-md-3">
                          <div class="coder-checkbox">
                          <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                          <span class="co-check-ui"></span>
                          <label>Hostel details</label>
                          </div>
                        </div>
                        <div class="form-group col-md-3">
                        <div class="coder-checkbox">
                        <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                        <span class="co-check-ui"></span>
                        <label>Hostel Room</label>
                        </div>
                        </div>
                        <div class="form-group col-md-3">
                        <div class="coder-checkbox">
                        <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                        <span class="co-check-ui"></span>
                        <label>Hostel Allocation</label>
                        </div>
                        </div>
                        <div class="form-group col-md-3">
                        <div class="coder-checkbox">
                        <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                        <span class="co-check-ui"></span>
                        <label>Hostel Register</label>
                        </div>
                        </div>
                        <div class="form-group col-md-3">
                        <div class="coder-checkbox">
                        <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                        <span class="co-check-ui"></span>
                        <label>Hostel Visitors </label>
                        </div>
                        </div>
                        <div class="form-group col-md-3">
                        <div class="coder-checkbox">
                        <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                        <span class="co-check-ui"></span>
                        <label>Hostel Avaliability Report</label>
                        </div>
                        </div>
                        <div class="form-group col-md-3">
                        <div class="coder-checkbox">
                        <input type="checkbox"  @if(permission($emp_roles->id,14)) checked @endif name="perms[]" value="14">
                        <span class="co-check-ui"></span>
                        <label>Room Occupancy Report</label>
                        </div>
                        </div>
                        </div>
                        </div>


                      </div>
                  </div>
                  <input type="hidden" value="{{$emp_roles->id}}" name="role_id">
                  <input type="hidden" name="_token" value="{{ csrf_token() }}">
                     <div class="box-footer col-md-6" style="border-top:none;">
                  <button type="submit" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i> Update </button>
  </div>
              </div>



</div>


</form>

          </div>
        </div>
              </div>
    </section>
    <!-- /.content -->
  </div>
  </div>
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')
<script src="{{ URL::asset('assets/bower_components/select2/dist/js/select2.full.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/chart.js/Chart.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/jszip.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/pdfmake.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/vfs_fonts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.html5.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.print.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.rowReorder.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/jquery/dist/bootbox.min.js') }}"></script>
<script>
        $(document).ready(function () {
            /*For Delete Application Info*/
            $(".tFileDelete").click(function (e) {
                e.preventDefault();
                var id = this.id;
                bootbox.confirm("Are you sure?", function (result) {
                    if (result) {
                        var _url = $("#_url").val();
                        window.location.href = _url + "/Academic-Details/delete/" + id;
                    }
                });
            });

        $("#viewedit").click(function () {
            $("#editview").show();
            $(this).hide();
            $("#edit").show();
            $("#view").hide();
        });
        $("#editview").click(function () {
            $("#viewedit").show();
            $(this).hide();
            $("#view").show();
            $("#edit").hide();
        });

        });
    </script>
<script>
$(document).ready(function() {
   $.extend($.fn.dataTable.defaults, {
 dom: 'Bfrtip'
});
   $('#example').DataTable( {

       buttons: [
           'copy', 'csv', 'excel', 'pdf', 'print'
       ],
         rowReorder: {
           selector: 'td:nth-child(2)'
       },
       responsive: true
   } );
   } );

</script>
@endsection
<!-- ./wrapper -->
