@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/responsive.dataTables.min.css') }}">

@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-aqua">
            <div class="inner">
              <h3>{{$student}}</h3>

              <p>Total Students</p>
            </div>
            <div class="icon">
              <i class="fa fa-fw fa-graduation-cap"></i>
            </div>
                  </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-green">
            <div class="inner">
              <h3>{{$emp}}</h3>

              <p>Total Employees</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
           </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-yellow">
            <div class="inner">
              <h3>{{$course}}</h3>

              <p>Total Course</p>
            </div>
            <div class="icon">
              <i class="fa fa-fw fa-book"></i>
            </div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-red">
            <div class="inner">
              <h3>{{$batch}}</h3>

              <p>Total Batch</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
          </div>
        </div>
        </div>
    <div class="row">
           <div class="col-md-12">
             <!-- AREA CHART -->
             <div class="box box-success">
               <div class="box-header with-border">
                 <h3 class="box-title">Fee Collection ({{date('F - Y')}})</h3>

                 <div class="box-tools pull-right">
                   <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                   </button>
                   <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                 </div>
               </div>
               <div class="box-body">
                 <div class="col-md-12">
                     <div id="expense" style="width:100%; height:400px;"></div>
                 </div>
               </div>
               <!-- /.box-body -->
             </div>
           </div>
           </div>
      <div class="row">
        <div class="col-md-8" style="visibility: hidden;">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Tab 1</a></li>
              <li><a href="#tab_2" data-toggle="tab">Tab 2</a></li>
              <li><a href="#tab_3" data-toggle="tab">Tab 3</a></li>
              <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                <b>How to use:</b>

                <p>Exactly like the original bootstrap tabs except you should use
                  the custom wrapper <code>.nav-tabs-custom</code> to achieve this style.</p>
                A wonderful serenity has taken possession of my entire soul,
                like these sweet mornings of spring which I enjoy with my whole heart.
                I am alone, and feel the charm of existence in this spot,
                which was created for the bliss of souls like mine. I am so happy,
                my dear friend, so absorbed in the exquisite sense of mere tranquil existence,
                that I neglect my talents. I should be incapable of drawing a single stroke
                at the present moment; and yet I feel that I never was a greater artist than now.
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                The European languages are members of the same family. Their separate existence is a myth.
                For science, music, sport, etc, Europe uses the same vocabulary. The languages only differ
                in their grammar, their pronunciation and their most common words. Everyone realizes why a
                new common language would be desirable: one could refuse to pay expensive translators. To
                achieve this, it would be necessary to have uniform grammar, pronunciation and more common
                words. If several languages coalesce, the grammar of the resulting language is more simple
                and regular than that of the individual languages.
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                sheets containing Lorem Ipsum passages, and more recently with desktop publishing software
                like Aldus PageMaker including versions of Lorem Ipsum.
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <div class="col-md-4">
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">FEE COLLECTION OF THE DAY</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <p>Total Collection (Today) :  {{$todaytotalfee}}</p>
              <p>Total Collection (Month) :  {{$monthtotalfee}}</p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-8" style="visibility: hidden;">
                 <div class="box">
                   <div class="box-header">
                     <h3 class="box-title">Task manager</h3>
                   </div>
                   <!-- /.box-header -->
                   <div class="box-body">
                     <table id="example" class="table table-striped table-bordered display nowrap">
                       <thead>
                       <tr>
                         <th>Sl.No</th>
                         <th>Task Description</th>
                         <th>Priority</th>
                         <th>Action</th>

                       </tr>
                       </thead>
                       <tbody>
                       <tr>
                         <td>Trident</td>
                         <td>Internet
                           Explorer 4.0
                         </td>
                         <td>Win 95+</td>
                         <td>
                       <div class="btn-group">
                         <button type="button" class="btn btn-default  btn-flat dropdown-toggle" data-toggle="dropdown">
                           <span class="caret"></span>
                           <span class="sr-only">Toggle Dropdown</span>
                         </button>
                         <ul class="dropdown-menu" role="menu" title="Action">
                           <li><a href="#" title="Edit"><i  class="fa fa-eye" style="color: #897df8e6";></i></a></li>
                           <li><a href="#" title="Delete"><i class="fa fa-trash" style="color: red";></i></a></li>
                         </ul>
                       </div>
                       </td>

                       </tr>
                       <tr>
                         <td>Trident</td>
                         <td>Internet
                           Explorer 5.0
                         </td>
                         <td>Win 95+</td>
                         <td>
                       <div class="btn-group">
                         <button type="button" class="btn btn-default  btn-flat dropdown-toggle" data-toggle="dropdown">
                           <span class="caret"></span>
                           <span class="sr-only">Toggle Dropdown</span>
                         </button>
                         <ul class="dropdown-menu" role="menu" title="Action">
                           <li><a href="#" title="Edit"><i  class="fa fa-eye" style="color: #897df8e6";></i></a></li>
                           <li><a href="#" title="Delete"><i class="fa fa-trash" style="color: red";></i></a></li>
                         </ul>
                       </div>
                       </td>


                       </tr>



                       </tbody>

                     </table>
                   </div>
                   <!-- /.box-body -->
                 </div>
                 <!-- /.box -->
               </div>
               <!-- /.col -->

            </div>
            </div>

        <!-- /.col -->
      </div>



    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')
<!--<script src="http://code.jquery.com/jquery-1.10.2.min.js" integrity="sha256-C6CB9UYIS9UJeqinPHWTHVqh/E1uhG5Twh+Y5qFQmYg="
			  crossorigin="anonymous"></script>-->
<script src="{{ URL::asset('assets/dist/js/highcharts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/jszip.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/pdfmake.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/vfs_fonts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.html5.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.print.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.rowReorder.min.js') }}"></script>

<script>
$(document).ready(function() {
   $.extend($.fn.dataTable.defaults, {
 dom: 'Bfrtip'
});
   $('#example').DataTable( {

       buttons: [
           'copy', 'csv', 'excel', 'pdf', 'print'
       ],
         rowReorder: {
           selector: 'td:nth-child(2)'
       },
       responsive: true


   } );
   } );

</script>
<script>
    $(document).ready(function () {
        var get_expense = <?php echo $feecollection; ?>;
        var tot_days=<?php echo $d ; ?>;
      //  alert(tot_days);
        var i=1;
        var get_expense_days = [
         <?php for($i=1;$i<=$d;$i++)
            {
                if($i!=$d)
                echo "{ day: $i, val: [] },";
                else
                 echo "{ day: $i, val: [] }";
            }

            ?>
        ];
      //  var data=JSON.parse(get_expense_days);
    //  alert();
//alert(get_expense);
        get_expense.forEach( function( item ) {
//alert(item.date);
          get_expense_days[new Date(item.date).getDate()-1].val.push( Number(item.amt));

        });
//alert();


get_expense_days=get_expense_days.map( function( item ) {
//item.val = 0;
 if ( item.val.length > 0 ) {
                item.val = item.val.reduce(function(a) {
                    return a;
                });
            } else {
                item.val = 0;
            }
                return item;
            });
        var get_expense_months = get_expense_days.map(function(item){
            return item.day;
        });

        var get_expense_amounts = get_expense_days.map(function(item){
            return item.val;
        });

      var cc=  Highcharts.chart('expense', {
            chart: {
    type: 'line'
},

            title: {
                text: ''
            },

            credits: {
                enabled: false
            },

            xAxis: {
                categories: [<?php for($i=1;$i<=$d;$i++){echo "'".$i."'," ;} ?>]
            },

            yAxis: {
                title: {
                    text: 'Amount'
                }
            },
            plotOptions: {
                line: {
        dataLabels: {
            enabled: true
        },
        enableMouseTracking: true
    },


            },

            series: [{
                name: 'Fee Collection',
                data: get_expense_amounts

            }
            ]

        });


    });
</script>
@endsection
<!-- ./wrapper -->
