@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/responsive.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/select2/dist/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/select.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.checkboxes.css') }}">
@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"><i class="fa fa-dashboard"></i> Student</a></li>
        <li class="active">Attendance</li>
      </ol>
    </section>
    <section class="content">
        @include('notification.notify')
  <div class="box box-default">
    <!-- Main content -->
    <div class="box-header with-border">
      <h3 class="box-title">Student Attendance</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
      </div>
    </div>

        <div class="row">
          <div class="col-md-12">
            <!-- Custom Tabs -->
            <div class="nav-tabs-custom">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#tab_1" data-toggle="tab">Attendance(Daily & Subject Wise)</a></li>
                <li><a href="#tab_2" data-toggle="tab">View Attendance</a></li>

                <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane active" id="tab_1">
                  <div class="box-body">
                    <div class="row">
                      <div class="col-md-12">

                        <!-- /.form-group -->
                        <div class="box box-primary">
                                 <div class="box-header with-border">
                                   <h3 class="box-title">Attendance</h3>
                                 </div>
                                 <!-- /.box-header -->
                                 <!-- form start -->
                                 <form role="form" method="post" enctype="multipart/form-data" action="{{url('finance/Fee-SubCategory/add')}}">
                                   <div class="box-body">
                                     <div class="col-md-12">
                                     <div class="form-group col-md-3">
                                       <label for="exampleInputEmail1">Course<span style="color:red;"> *</span></label>
                                       <select class="form-control select2" name="fee_category" id="course" style="width: 100%;" required>
                                           <option value="" selected="selected">Please Select</option>
                                           <?php foreach ($course as $course): ?>
                                                <option value="{{$course->id}}">{{$course->course_name}}</option>
                                           <?php endforeach; ?>
                                     </select>
                                        </div>
                                        <div id="att" style="display:none;">
                                        <div class="form-group col-md-3">
                                          <label for="exampleInputEmail1">Batch/Section<span style="color:red;"> *</span></label>
                                          <select class="form-control select2" name="fee_category" id="batch" style="width: 100%;" required>
                                              <option value="" selected="selected">Please Select</option>
                                        </select>
                                           </div>
                                           <div class="form-group col-md-3">
                                             <label for="exampleInputEmail1">Subject<span style="color:red;"> *</span></label>
                                             <select class="form-control select2" name="fee_category" id="subject" style="width: 100%;" required>
                                                 <option value="" selected="selected">Please Select</option>
                                           </select>
                                              </div>
                                              <div class="form-group">
                                              <label>Date</label>
                                              <div class="input-group date">
                                                <div class="input-group-addon">
                                                  <i class="fa fa-calendar"></i>
                                                </div>
                                                <input type="text" class="form-control pull-right" id="startdate" name="startdate">
                                              </div>
                                              <!-- /.input group -->
                                            </div>

                                        </div>

                                   </div>

                                 </div>
</form>
                               </div>
                               <div class="row">
                                 <div class="form-group col-md-12">
                               <div class="callout callout-info">
                                 <span class="pull-left-container">
                                   <i class="fa fa-info-circle pull-left"></i>
                                 </span>
                                 <p>Put mark on students who were present.</p>
                               </div>
                               </div>
                               </div>
                               <div class="box-body">
                                 <table id="example" class="table table-striped table-bordered display" style="width:100%">
                                   <thead>
                                   <tr>
                                     <th></th>
                                     <th>Roll No</th>
                                     <th>Admission No</th>
                                     <th>Student Name</th>
                                     <th>Remark</th>
                                   </tr>
                                   </thead>
                                   <tbody>


                                   </tbody>

                                 </table>
                               </div>
                               <a class="btn btn-primary" id="save">Save </a>
                      </div>
            </div>
          </div>
        </div>
                <!-- /.tab-pane -->
                <div class="tab-pane" id="tab_2">
                  <form role="form" method="post" enctype="multipart/form-data" action="">
                  <div class="box-body">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="box box-info">
                          <div class="box-header">
                            <h3 class="box-title">Attendance</h3>
                          </div>
                            <div class="box-body">
                              <div class="col-md-12">
                              <div class="form-group col-md-3">
                                <label for="exampleInputEmail1">Course<span style="color:red;"> *</span></label>
                                <select class="form-control select2" name="fee_category" id="courses" style="width: 100%;" required>
                                    <option value="" selected="selected">Please Select</option>
                                    <?php foreach ($courses as $course): ?>
                                         <option value="{{$course->id}}">{{$course->course_name}}</option>
                                    <?php endforeach; ?>
                              </select>
                                 </div>

                                 <div class="form-group col-md-3">
                                   <label for="exampleInputEmail1">Batch/Section<span style="color:red;"> *</span></label>
                                   <select class="form-control select2" name="fee_category" id="batchs" style="width: 100%;" required>
                                       <option value="" selected="selected">Please Select</option>
                                 </select>
                                    </div>
                                    <div class="form-group col-md-3">
                                      <label for="exampleInputEmail1">Accadmic year<span style="color:red;"> *</span></label>
                                      <select class="form-control select2" name="fee_category" id="accadmicyear" style="width: 100%;" required>
                                          <option value="" selected="selected">Please Select</option>
                                          <?php foreach ($accadmicyear as $accadmicyear): ?>
                                               <option value="{{$accadmicyear->startyear}}-{{$accadmicyear->endyear}}">{{$accadmicyear->startyear}}-{{$accadmicyear->endyear}}</option>
                                          <?php endforeach; ?>
                                    </select>
                                       </div>
                                       <div class="form-group col-md-3">
                                         <label for="exampleInputEmail1">Month<span style="color:red;"> *</span></label>
                                         <select class="form-control select2" name="fee_category" id="months" style="width: 100%;" required>
                                             <option value="" selected="selected">Please Select</option>
                                             <option value="January">January</option>
                                             <option value="February">February</option>
                                             <option value="March">March</option>
                                             <option value="April">April</option>
                                             <option value="May">May</option>
                                             <option value="May">June</option>
                                             <option value="July">July</option>
                                             <option value="August">August</option>
                                             <option value="September">September</option>
                                             <option value="October">October</option>
                                             <option value="November">November</option>
                                             <option value="December">December</option>
                                       </select>
                                          </div>
                            </div>
                          <!-- /.box-header -->


                        </div>
                          <!-- /.box-body -->
                        </div>
              </div>
                        </div>
                        </div>

                        <div class="box-body" id="reports">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="box box-info">
                                <div class="box-header">
                                  <h3 class="box-title">Attendance Report For </h3>
                                </div>
                                  <div class="box-body">
                                    <div class="col-md-12">

                                      <table id="reporttable" class="table table-striped table-bordered display" style="width:100%">
                                        <thead>
                                  <tr>
                                  <th>Sl. No.</th>
                                  <th>Student Name</th>
                                  <th>1</th>
                                  <th>2</th>
                                  <th>3</th>
                                  <th>4</th>
                                  <th>5</th>
                                  <th>6</th>
                                  <th>7</th>
                                  <th>8</th>
                                  <th>9</th>
                                  <th>10</th>
                                  <th>11</th>
                                  <th>12</th>
                                  <th>13</th>
                                  <th>14</th>
                                  <th>15</th>
                                  <th>16</th>
                                  <th>17</th>
                                  <th>18</th>
                                  <th>19</th>
                                  <th>20</th>
                                  <th>21</th>
                                  <th>22</th>
                                  <th>23</th>
                                  <th>24</th>
                                  <th>25</th>
                                  <th>26</th>
                                  <th>27</th>
                                  <th>28</th>
                                  <th>29</th>
                                  <th>30</th>
                                  <th>31</th>
                                    </tr>
                                </thead>
                                        <tbody>
                                          <tr>
                                          </tr>

                                        </tbody>

                                      </table>



                                  </div>
                                <!-- /.box-header -->


                              </div>
                                <!-- /.box-body -->
                              </div>
                    </div>
                              </div>
                              </div>
                      </form>
                </div>


              <!-- /.tab-content -->
            </div>
            <!-- nav-tabs-custom -->

    </section>
    <!-- /.content -->
  </div>
  </div>
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')
<script src="{{ URL::asset('assets/bower_components/select2/dist/js/select2.full.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/chart.js/Chart.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/jszip.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/pdfmake.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/vfs_fonts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.html5.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.print.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.rowReorder.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/jquery/dist/bootbox.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.select.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.checkboxes.min.js') }}"></script>
<script>
function daysInMonth (month, year) { // Use 1 for January, 2 for February, etc.
  return new Date(year, month, 0).getDate();
}      $.extend($.fn.dataTable.defaults, {
    dom: 'Bfrtip'
   });
   var reporttable=   $('#reporttable').DataTable( {

          buttons: [
              'copy', 'csv', 'excel', 'pdf', 'print'
          ],
          pageLength: 100,
          responsive: true,
          scrollY:        "300px",
           scrollX:        true,
           scrollCollapse: true,
           paging:         false,
           columnDefs: [
               { width: 200, targets: 0 }
           ],
           fixedColumns: true,
           bDestroy: true


      } );
       $(document).ready(function () {

           /*For Details Loading*/
           $("#months").change(function () {
            var tb = $('#example').DataTable({
            scrollY:        "300px",
            scrollX:        true,
            scrollCollapse: true,
            paging:         false,
            columnDefs: [
                { width: 200, targets: 0 }
            ],
            fixedColumns: true,
          
            bDestroy: true,
            });
               var id = $(this).val();
               var batch=$("#batchs").val();
               var course=$("#courses").val();
              if (id == "April")
              {
                reporttable.columns([32]).visible(false);
              }else{
                reporttable.columns([32]).visible(true);
              }
              if (id == "June")
              {
                reporttable.columns([32]).visible(false);
              }else{
                reporttable.columns([32]).visible(true);
              }
              if (id == "September")
              {
                reporttable.columns([32]).visible(false);
              }else{
                reporttable.columns([32]).visible(true);
              }
              if (id == "November")
              {
                reporttable.columns([32]).visible(false);
              }else{
                reporttable.columns([32]).visible(true);
              }
              if (id == "February")
              {
                reporttable.columns([31,32]).visible(false);
              }else{
                reporttable.columns([31,32]).visible(true);
              }
              var _url = $("#_url").val();
              $.ajax
              ({
                  type: "POST",
                  url: _url + '/student/attendance/report',
                  data:  {month:id,course:course,batch:batch},
                  cache: false,
                  success: function ( data ) {
                    data=JSON.parse(data);
                   for (var i in data) {
                     var name=data[i]['name'];
                  //   sumamt+= parseInt(v);
                  var days=data[i]['day'];
              //    alert(name);
                  if(days=='1'){
                     var d1=data[i]['status'];
                  }
                  if(days=='2'){
                     var d2=data[i]['status'];
                  }
                  if(days=='3'){
                     var d3=data[i]['status'];
                  }
                  if(days=='4'){
                     var d4=data[i]['status'];
                  }
                  if(days=='5'){
                     var d5=data[i]['status'];
                  }
                  if(days=='6'){
                     var d6=data[i]['status'];
                  }
                  if(days=='7'){
                     var d7=data[i]['status'];
                  }
                  if(days=='8'){
                     var d8=data[i]['status'];
                  }
                  if(days=='9'){
                     var d9=data[i]['status'];
                  }
                  if(days=='10'){
                     var d10=data[i]['status'];
                  }
                  if(days=='11'){
                     var d11=data[i]['status'];
                  }
                  if(days=='12'){
                     var d12=data[i]['status'];
                  }
                  if(days=='13'){
                     var d13=data[i]['status'];
                  }
                  if(days=='14'){
                     var d14=data[i]['status'];
                  }
                  if(days=='15'){
                     var d15=data[i]['status'];
                  }
                  if(days=='16'){
                     var d16=data[i]['status'];
                  }
                  if(days=='17'){
                     var d17=data[i]['status'];
                  }
                  if(days=='18'){
                     var d18=data[i]['status'];
                  }
                  if(days=='19'){
                     var d19=data[i]['status'];
                  }
                  if(days=='20'){
                     var d20=data[i]['status'];
                  }
                  if(days=='21'){
                     var d21=data[i]['status'];
                  }
                  if(days=='22'){
                     var d22=data[i]['status'];
                  }
                  if(days=='23'){
                     var d23=data[i]['status'];
                  }
                  if(days=='24'){
                     var d24=data[i]['status'];
                  }
                  if(days=='25'){
                     var d25=data[i]['status'];
                  }
                  if(days=='26'){
                     var d26=data[i]['status'];
                  }
                  if(days=='27'){
                     var d27=data[i]['status'];
                  }
                  if(days=='28'){
                     var d28=data[i]['status'];
                  }
                  if(days=='29'){
                     var d29=data[i]['status'];
                  }
                  if(days=='30'){
                     var d30=data[i]['status'];
                  }
                  if(days=='31'){
                     var d31=data[i]['status'];
                  }

                     tb.row.add( [
                            name,
                            d1,
                            d2,
                            d3,
                            d4,
                            d5,
                            d6,
                            d7,
                            d8,
                            d9,
                            d10,
                            d11,
                            d12,
                            d13,
                            d14,
                            d15,
                            d16,
                            d17,
                            d18,
                            d19,
                            d20,
                            d21,
                            d22,
                            d23,
                            d24,
                            d25,
                            d26,
                            d27,
                            d28,
                            d29,
                            d30,
                            d31
                            ] ).draw( false );

                   }



                  },
                  error: function (jqXHR, exception) {
       var msg = '';
       if (jqXHR.status === 0) {
            $("#stuinfo").hide();
            $("#rollno").val('');
           msg = 'Not connect.\n Verify Network.';

       } else if (jqXHR.status == 404) {
            $("#stuinfo").hide();
            $("#rollno").val('');
           msg = 'Requested page not found. [404]';

       } else if (jqXHR.status == 500) {
            $("#stuinfo").hide();
            $("#rollno").val('');
           msg = 'Internal Server Error [500].';


       } else if (exception === 'parsererror') {
          $("#stuinfo").hide();
          $("#rollno").val('');
           msg = 'Requested JSON parse failed.';

       } else if (exception === 'timeout') {
          $("#stuinfo").hide();
          $("#rollno").val('');
           msg = 'Time out error.';
       } else if (exception === 'abort') {
          $("#stuinfo").hide();
          $("#rollno").val('');
           msg = 'Ajax request aborted.';
       } else {
          $("#stuinfo").hide();
          $("#rollno").val('');
           msg = 'Uncaught Error.\n' + jqXHR.responseText;
       }
       alert(msg);
   },
              });




           });

          });

   </script>
<script>
       $(document).ready(function () {

           /*For Details Loading*/
           $("#courses").change(function () {
              $("#att").hide();
             $("#att").toggle();
               var id = $(this).val();
               var _url = $("#_url").val();
               var dataString = 'eid=' + id;
               $.ajax
               ({
                   type: "POST",
                   url: _url + '/student/batchlist',
                   data: dataString,
                   cache: false,
                   success: function ( data ) {
                     data=JSON.parse(data);

                        // alert(data);
                         var list = $("#batchs");
                      $(list).empty().append('<option selected="selected" value=""> Please Select </option>');

                     $(data).empty();
                      var emptycarno="No batch available for this course";
             if(data.length==""){
                        $("#batchs").append('<option value="' +emptycarno +'">' + emptycarno + '</option>');
             }
               else{
                        for (var i in data) {
                          var v=data[i]['id'];
                          var v1=data[i]['batch_name'];
                          $(list).append('<option value="' +v +'">' + v1 + '</option>');

                       }
           }

                   },
                   error: function (jqXHR, exception) {
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
        alert(msg);
    },
               });
           });

          });

   </script>
<script>
       $(document).ready(function () {

           /*For Details Loading*/
           $("#course").change(function () {
              $("#att").hide();
             $("#att").toggle();
               var id = $(this).val();
               var _url = $("#_url").val();
               var dataString = 'eid=' + id;
               $.ajax
               ({
                   type: "POST",
                   url: _url + '/student/batchlist',
                   data: dataString,
                   cache: false,
                   success: function ( data ) {
                     data=JSON.parse(data);

                        // alert(data);
                         var list = $("#batch");
                      $(list).empty().append('<option selected="selected" value=""> Please Select </option>');

                     $(data).empty();
                      var emptycarno="No batch available for this course";
             if(data.length==""){
                        $("#batch").append('<option value="' +emptycarno +'">' + emptycarno + '</option>');
             }
               else{
                        for (var i in data) {
                          var v=data[i]['id'];
                          var v1=data[i]['batch_name'];
                          $(list).append('<option value="' +v +'">' + v1 + '</option>');

                       }
           }

                   },
                   error: function (jqXHR, exception) {
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
        alert(msg);
    },
               });
           });

          });

   </script>

   <script>
          $(document).ready(function () {
            var student = [];
            var studentids = [];
             var attendancelist={};
var t = $('#example').DataTable({
    columnDefs: [
        {
     orderable: false,
     className: 'select-checkbox',
     targets:   0,
        }
    ],
    select:{
       style: 'multi',
       selector: 'td:first-child'
    },
     pageLength: 100,
    order: [[1, 'asc']]

});
              /*For Details Loading*/
              $("#batch").change(function () {

                  var id = $(this).val();
                  var course = $("#course").val();
                  var _url = $("#_url").val();
                  $.ajax
                  ({
                      type: "POST",
                      url: _url + '/student/attendance/getstudent',
                      data: {batch: id, course:course},
                      cache: false,
                      success: function ( data ) {
                        //  alert(data);
                      //   var t = $('#example').DataTable();
                            data=JSON.parse(data);
                              //  alert(data);
                             for (var i in data) {
                               var v1=data[i]['reg_no'];
                               var v2=data[i]['fname'];
                               var v3=data[i]['mname'];
                                var v4=data[i]['lname'];
                                 var v5=data[i]['roll_no'];
                            //   var markup = "<tr><td></td><td>"+v5+"</td><td>"+v1+"</td><td>" + v2 +  " " + v3 +  " " + v4 +  " </td><td></td></tr>";
                            //  alert(v1);
                            t.row.add( [
                                    ''  ,
                                    v5,
                                    v1,
                                    v2+" "+ v3+" " + v4,
                                    ''
                                   ] ).draw( false );
                          //     $('#example').append('<tbody>' + markup + '</tbody>');
                             }
                      },
                      error: function (jqXHR, exception) {
           var msg = '';
           if (jqXHR.status === 0) {
               msg = 'Not connect.\n Verify Network.';
           } else if (jqXHR.status == 404) {
               msg = 'Requested page not found. [404]';
           } else if (jqXHR.status == 500) {
               msg = 'Internal Server Error [500].';
           } else if (exception === 'parsererror') {
               msg = 'Requested JSON parse failed.';
           } else if (exception === 'timeout') {
               msg = 'Time out error.';
           } else if (exception === 'abort') {
               msg = 'Ajax request aborted.';
           } else {
               msg = 'Uncaught Error.\n' + jqXHR.responseText;
           }
           alert(msg);
       },
                  });
              });


                $("#example tbody").on('click', 'tr', function (event){
  //alert();
              if(($(this).hasClass("selected")).length!=0){
                  if($(this).hasClass("selected")){
                //  alert("unchecked");
                   var stu_name = $(this).find("td").eq(2).html();
                   var remark = $(this).find('td:eq(4) input').val();
                   student.pop();
                   studentids.pop();
              //     alert(student);
                     }
                  else{
                      var stu_name = $(this).find("td").eq(2).html();
                      var remark = $(this).find('td:eq(4) input').val();
                      student.push(stu_name);
                      studentids.push({'reg_no':stu_name});
                      //attendancelist
                      student.push(remark);
                  //     alert(stu_name);

                  }

              //    alert(studentids);
                     attendancelist = JSON.stringify(studentids);
                    }else{
                      alert("Please Select Student.");
                    }
              });
              /*For Details Loading*/
              $("#save").click(function () {
              //  alert(attendancelist);
                 var _url = $("#_url").val();
                 var date=$("#startdate").val();
                 var course=$("#course").val();
                 var batch=$("#batch").val();
                 if(course !=""){
                 if(date!=""){
                  $.ajax
                  ({
                      type: "POST",
                      url: _url + '/student/attendance/save',
                      data:{date: date,course:course,batch:batch,stu_id:attendancelist},
                      cache: false,
                      success: function ( data ) {
                      //    data=JSON.parse(data);
                          console.log(data);
                        alert(data);
                        table = $("#example").DataTable();
                        table.rows( '.selected' ).nodes().to$().removeClass( 'selected' );
                      //  console.log(data);
                                //    data=JSON.parse(data);

                      },
                      error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
               msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
               msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
               msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
               msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
               msg = 'Time out error.';
            } else if (exception === 'abort') {
               msg = 'Ajax request aborted.';
            } else {
               msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            alert(msg);
            },
                  });

            }else{
              alert("Please Select Date First");
            }
            }else{
            alert("Please Select Course First");
            }
              });

             });

      </script>

<script>
        $(document).ready(function () {

            /*For Delete Application Info*/
            $(".tFileDelete").click(function (e) {
                e.preventDefault();
                var id = this.id;
                bootbox.confirm("Are you sure?", function (result) {
                    if (result) {
                        var _url = $("#_url").val();
                        window.location.href = _url + "/Academic-Details/delete/" + id;
                    }
                });
            });



        });
    </script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2();
    $('#startdate').datepicker({
      autoclose: true,
      format:'dd-mm-yyyy'
    });
    $('.dob').datepicker({
      autoclose: true,
      format:'dd-mm-yyyy',
      maxDate: 0
    });
  });
</script>
@endsection
<!-- ./wrapper -->
