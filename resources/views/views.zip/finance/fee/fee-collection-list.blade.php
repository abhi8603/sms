@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/responsive.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/select2/dist/css/select2.min.css') }}">

@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#"><i class="fa fa-dashboard"></i>Finance</a></li>
        <li><a href="#"><i class="fa fa-dashboard"></i>Fee-Collection</a></li>
        <li class="active">List</li>
      </ol>
    </section>

    <!-- Main content -->
      <section class="content">
          @include('notification.notify')
    <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Search Fee Collection</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="box box-primary">
                           <form role="form" method="post" enctype="multipart/form-data" action="{{url('finance/feeCollection/search')}}">
                          <div class="box-body">
                             <div class="col-md-3">
                            <div class="form-group">
                              <label for="exampleInputEmail1">Student/Registration No.</label>
                              <select class="form-control select2" name="student" style="width: 100%;">
                                  <option value="0" selected="selected">Please select</option>
                                  <?php foreach ($students as $students): ?>
                                    <option value="{{$students->reg_no}}">{{$students->fname}} {{$students->mname}} {{$students->lname}} ({{$students->reg_no}})</option>
                                  <?php endforeach; ?>
                           </select>
                         </div>
                       </div>
                         <div class="form-group">
                           <div class="col-md-3">
                           <label for="exampleInputEmail1">Course/Class</label>
                           <select class="form-control select2" name="batch" style="width: 100%;">
                               <option value="0" selected="selected">Please select</option>
                               <?php foreach ($batch as $batch): ?>
                                 <option value="{{$batch->course_name}}">{{$batch->course_name}} - {{$batch->batch_name}}</option>
                               <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-3" style="top: -15px;">
                      <label for="exampleInputEmail1">Months</label>
                      <select class="form-control select2"  id="month" name="month" style="width: 100%;">
                         <option value="0" selected="selected">Please Select Months</option>
                          <option value="1" >January</option>
                          <option value="2" >February</option>
                          <option value="3" >March</option>
                          <option value="4" >April</option>
                          <option value="5" >May</option>
                          <option value="6" >June</option>
                          <option value="7" >July</option>
                          <option value="8" >August</option>
                          <option value="9" >September</option>
                          <option value="10" >October</option>
                          <option value="11" >November</option>
                          <option value="12" >December</option>
                   </select>
                 </div>
                 </div>
               <div class="form-group">
                 <div class="col-md-3" style="top: 8px;">
                 <button type="submit" class="btn btn-primary">Search</button>
                 <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
            </div>
          </div>
             </div>
   </form>
   </div>

                  <!-- /.form-group -->
                </div>

                <div class="col-md-12">
                  <div class="box box-info">
                    <div class="box-header">
                      <h3 class="box-title">Task manager</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                      <table id="example" class="table table-striped table-bordered display nowrap" style="width:100%">
                        <thead>
                  <tr>
                  <th>Sl. No.</th>
                  <th>Admission No.</th>
                  <th>Student Name</th>
                  <th>Course</th>
                  <th>Batch</th>
                  <th>Amount</th>
                  <th>Month</th>
                  <th>Date</th>
                  <th>Manage</th>
                    </tr>
                </thead>
                        <tbody>
                          @php $i=0; @endphp
                          @foreach($feeslist as $feeslist)
                          @php $i++; @endphp
                          <tr>
                            <td>@php echo $i; @endphp</td>
                            <td>{{$feeslist->stu_reg_no}}</td>
                            <td>{{$feeslist->stu_name}}</td>
                            <td>{{$feeslist->class}}</td>
                            <td>{{$feeslist->section}}</td>
                            <td>{{$feeslist->amt}}</td>
                            @if($feeslist->month=='1')
                                <td>January</td>
                            @elseif($feeslist->month=='2')
                                <td>February</td>

                            @elseif($feeslist->month=='3')
                                <td>March</td>

                            @elseif($feeslist->month=='4')
                                <td>April</td>

                            @elseif($feeslist->month=='5')
                                <td>May</td>

                            @elseif($feeslist->month=='6')
                                <td>June</td>

                            @elseif($feeslist->month=='7')
                                <td>July</td>

                            @elseif($feeslist->month=='8')
                                <td>August</td>

                            @elseif($feeslist->month=='9')
                                <td>September</td>

                            @elseif($feeslist->month=='10')
                                <td>October</td>

                            @elseif($feeslist->month=='11')
                                <td>November</td>

                            @elseif($feeslist->month=='12')
                                <td>December</td>

                          @endif
                            <td>{{$feeslist->created_date}}</td>
                            <td>
                          <div class="btn-group">
                            <button type="button" class="btn btn-default  btn-flat dropdown-toggle" data-toggle="dropdown">
                              <span class="caret"></span>
                              <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu" title="Action">
                              <li><a href="{{url('finance/feeCollection/receipt/'.$feeslist->receipt_no)}}" title="View"><i  class="fa fa-eye" style="color: #897df8e6";></i></a></li>
                            </ul>
                          </div>
                          </td>

                          </tr>
                          @endforeach
                        </tbody>

                      </table>
                    </div>
                    <!-- /.box-body -->
                  </div>
                </div>
              </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')
<script src="{{ URL::asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/select2/dist/js/select2.full.min.js') }}"></script>

<script src="{{ URL::asset('assets/bower_components/chart.js/Chart.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/jszip.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/pdfmake.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/vfs_fonts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.html5.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.print.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.rowReorder.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/jquery/dist/bootbox.min.js') }}"></script>
<script>
        $(document).ready(function () {
            /*For Delete Application Info*/
            $(".tFileDelete").click(function (e) {
                e.preventDefault();
                var id = this.id;
                bootbox.confirm("Are you sure?", function (result) {
                    if (result) {
                        var _url = $("#_url").val();
                        window.location.href = _url + "/student/delete/" + id;
                    }
                });
            });

        });
    </script>
<script>
$(document).ready(function() {
   $.extend($.fn.dataTable.defaults, {
 dom: 'Bfrtip'
});
   $('#example').DataTable( {

       buttons: [
           'copy', 'csv', 'excel', 'pdf', 'print'
       ],

       responsive: true


   } );
   } );

</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()


  })
</script>
<script>
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
@endsection
<!-- ./wrapper -->
