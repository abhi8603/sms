@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap/dist/css/responsive.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap-daterangepicker/daterangepicker.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/select2/dist/css/select2.min.css') }}">

@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">


    <!-- Main content -->
      <section class="content">
          @include('notification.notify')
    <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Fee Receipt</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="box box-primary">
                           <form role="form" method="post" enctype="multipart/form-data" action="{{url('student/postsearch')}}">
                           <div id="printdiv">
                          <div class="box-body">
                             <div class="col-md-3">
                            <div class="form-group">
                              <img src="{{ $logo or "assets/dist/img/user2-160x160.jpg"}}" title="logo"/>
                         </div>
                       </div>

                       <div class="col-md-4" style="position: inherit;text-align: center;">
                      <div class="form-group" >
                      <h4 >{{ Auth::user()->school_name }}</h4>
                      </div>
                   </div>
                   <div class="col-md-3" style="position: inherit;text-align: center;float:right">
                  <div class="form-group" >
                <small>{{date('l dS F - Y')}}</small>
                  </div>
               </div>
                 </div>
                 <div class="box-body box box-info">
                    <div class="col-md-6">
                   <div class="form-group" style="text-align: center;">
                  <label>Name : </label>
                    <label>{{$stu_name}}</label>
                </div>
              </div>

              <div class="col-md-6">
             <div class="form-group">
            <label>Course/Subject : </label>
              <label> {{$class}}</label>
          </div>
        </div>
        <div class="col-md-6">
       <div class="form-group" style="text-align: center;">
      <label>Admission No : </label>
        <label>{{$stu_reg_no}}</label>
    </div>
  </div>

  <div class="col-md-6">
 <div class="form-group">
<label>Batch/Section : </label>
  <label>{{$section}}</label>
</div>
</div>
<div class="col-md-6">
<div class="form-group" style="text-align: center;">
<label>Receipt No. : </label>
<label>{{$id}}</label>
</div>
</div>

<div class="col-md-6">
<div class="form-group">
<label>Date : </label>
<label>{{$date}} </label>
</div>
</div>
</div>

<div class="box-body">
  <table id="example" class="table table-striped table-bordered display nowrap" style="width:100%">
    <thead>
<tr>
<th>Fee Head</th>
<th>Fee Name</th>
<th>Month</th>
<th>Amount</th>
<th>Date</th>
</tr>
</thead>
    <tbody>

@foreach($receipts as $receipt)
      <tr>
        <td>{{$receipt->fee_head}}</td>
        <td>{{$receipt->fee_category}}</td>
        @if($receipt->month=='1')
            <td>January</td>
        @elseif($receipt->month=='2')
            <td>February</td>
        @elseif($receipt->month=='3')
            <td>March</td>

        @elseif($receipt->month=='4')
            <td>April</td>

        @elseif($receipt->month=='5')
            <td>May</td>

        @elseif($receipt->month=='6')
            <td>June</td>

        @elseif($receipt->month=='7')
            <td>July</td>

        @elseif($receipt->month=='8')
            <td>August</td>

        @elseif($receipt->month=='9')
            <td>September</td>

        @elseif($receipt->month=='10')
            <td>October</td>

        @elseif($receipt->month=='11')
            <td>November</td>

        @elseif($receipt->month=='12')
            <td>December</td>
        @else
          <td></td>

      @endif
        <td class="price">{{$receipt->amt}}</td>
        <td>{{$receipt->created_date}}</td>


      </tr>
      @endforeach
    </tbody>

  </table>
</div>
<div class="col-md-12" style="margin-top:10px">
  <div class="col-md-6">
<div class="form-group" style="margin-bottom: -2px;">
</div>
</div>
<div class="col-md-6">
<div class="form-group" style="margin-bottom: -2px;margin-left: 75px;padding: 10px;">
  <label >Total  : </label>

    <label id="totamt"> </label>
</div>

</div>

  <div class="col-md-6">
<div class="form-group" style="margin-bottom: -2px;">
<label>Address : </label>
<label>{{$address OR ''}} </label>
</div>
<div class="form-group" style="margin-bottom: -2px;">
<label>Phone : </label>
<label>{{$Institutionphone OR ''}} </label>
</div>
<div class="form-group" style="margin-bottom: -2px;">
<label>Fax : </label>
<label>{{$Institutionfax OR ''}} </label>
</div>
<div class="form-group" style="margin-bottom: -2px;">
<label>Email : </label>
<label>{{$InstitutionEmail OR ''}} </label>
</div>
</div>
<div class="col-md-6">
<div class="form-group" style="margin-bottom: -2px;">
<label>Signature : </label>
</div>
</div>
</div>
   </div>
<div class="form-group" style="margin-top: 10px;">
  <div class="col-md-3" style="margin-top: 40px;">
  <a  class="btn btn-primary" onclick="javascript:printDiv('printdiv')">Print Receipt</a>


</div>
<div class="col-md-3" style="margin-top: 40px;">
<a  href="{{url('finance/feeCollection/receipt/download/4')}}" class="btn btn-primary">Download Receipt</a>
<input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
</div>
</div>
 </div>
   </form>


                  <!-- /.form-group -->
                </div>


              </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')


<script src="{{ URL::asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/jszip.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/pdfmake.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/vfs_fonts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.html5.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.print.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.rowReorder.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/jquery/dist/bootbox.min.js') }}"></script>
<script>
var result = [];
   $('.price').each(function(index, val){
     if(!result[index]) result[index] = 0;
      result[index] += parseInt($(this).text());
    });

  var total=0;
  for (var i = 0; i < result.length; i++) {
    total += result[i];
}

$('#totamt').html(total);
</script>
<script language="javascript" type="text/javascript">
       function printDiv(divID) {
           //Get the HTML of div
           var divElements = document.getElementById(divID).innerHTML;
           //Get the HTML of whole page
           var oldPage = document.body.innerHTML;

           //Reset the page's HTML with div's HTML only
           document.body.innerHTML =
             "<html><head><title></title></head><body>" +
             divElements + "</body>";

           //Print Page
           window.print();

           //Restore orignal HTML
           document.body.innerHTML = oldPage;


       }
   </script>

<script>
$(document).ready(function() {
   $('#example').DataTable( {
     paging: false.
       responsive: true

   } );


   } );

</script>
@endsection
<!-- ./wrapper -->
