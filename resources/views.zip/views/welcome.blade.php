@extends('header')
@section('style')
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/jquery.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/rowReorder.dataTables.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('assets/bower_components/datatables.net-bs/css/responsive.dataTables.min.css') }}">

@endsection
@section('content')
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    @if(Auth::user()->id==1)
    <!-- Main content -->
    <section class="content" style="min-height: 1509px !important;">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-aqua">
            <div class="inner">
              <h3>{{$student}}</h3>

              <p>Total Students</p>
            </div>
            <div class="icon">
              <i class="fa fa-fw fa-graduation-cap"></i>
            </div>
                  </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-green">
            <div class="inner">
              <h3>{{$emp}}</h3>

              <p>Total Employees</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
           </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-yellow">
            <div class="inner">
              <h3>{{$course}}</h3>

              <p>Total Course/Class</p>
            </div>
            <div class="icon">
              <i class="fa fa-fw fa-book"></i>
            </div>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div style="border-radius: 15px 1px;" class="small-box bg-red">
            <div class="inner">
              <h3>{{$batch}}</h3>

              <p>Total Batch/Section</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
          </div>
        </div>
        </div>
    <div class="row">
           <div class="col-md-12">
             <!-- AREA CHART -->
             <div class="box box-success">
               <div class="box-header with-border">
                 <h3 class="box-title">Fee Collection ({{date('F - Y')}})</h3>

                 <div class="box-tools pull-right">
                   <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                   </button>
                   <button style="display:none;" type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                 </div>
               </div>
               <div class="box-body">
                 <div class="col-md-12">
                     <div id="expense" style="width:100%; height:400px;"></div>
                 </div>
               </div>
               <!-- /.box-body -->
             </div>
           </div>
           </div>
           <div class="row">
           <div class=col-md-12>
           <div class=col-md-8>
           <div class="box box-solid bg-green-gradient">
            <div class="box-header ui-sortable-handle" style="cursor: move;">
              <i class="fa fa-calendar"></i>

              <h3 class="box-title">Calendar</h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
                <!-- button with a dropdown -->
                <div class="btn-group">
                  <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-bars"></i></button>
                  <ul class="dropdown-menu pull-right" role="menu">
                    <li><a href="#">Add new event</a></li>
                    <li><a href="#">Clear events</a></li>
                    <li class="divider"></li>
                    <li><a href="#">View calendar</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-success btn-sm" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-success btn-sm" data-widget="remove"><i class="fa fa-times"></i>
                </button>
              </div>
              <!-- /. tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <!--The calendar -->
              <div id="calendar" style="width: 100%"><div class="datepicker datepicker-inline"><div class="datepicker-days" style=""><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">«</th><th colspan="5" class="datepicker-switch">April 2020</th><th class="next">»</th></tr><tr><th class="dow">Su</th><th class="dow">Mo</th><th class="dow">Tu</th><th class="dow">We</th><th class="dow">Th</th><th class="dow">Fr</th><th class="dow">Sa</th></tr></thead><tbody><tr><td class="old day" data-date="1585440000000">29</td><td class="old day" data-date="1585526400000">30</td><td class="old day" data-date="1585612800000">31</td><td class="day" data-date="1585699200000">1</td><td class="day" data-date="1585785600000">2</td><td class="day" data-date="1585872000000">3</td><td class="day" data-date="1585958400000">4</td></tr><tr><td class="day" data-date="1586044800000">5</td><td class="day" data-date="1586131200000">6</td><td class="day" data-date="1586217600000">7</td><td class="day" data-date="1586304000000">8</td><td class="day" data-date="1586390400000">9</td><td class="day" data-date="1586476800000">10</td><td class="day" data-date="1586563200000">11</td></tr><tr><td class="day" data-date="1586649600000">12</td><td class="day" data-date="1586736000000">13</td><td class="day" data-date="1586822400000">14</td><td class="day" data-date="1586908800000">15</td><td class="day" data-date="1586995200000">16</td><td class="day" data-date="1587081600000">17</td><td class="day" data-date="1587168000000">18</td></tr><tr><td class="day" data-date="1587254400000">19</td><td class="day" data-date="1587340800000">20</td><td class="day" data-date="1587427200000">21</td><td class="day" data-date="1587513600000">22</td><td class="day" data-date="1587600000000">23</td><td class="day" data-date="1587686400000">24</td><td class="day" data-date="1587772800000">25</td></tr><tr><td class="day" data-date="1587859200000">26</td><td class="day" data-date="1587945600000">27</td><td class="day" data-date="1588032000000">28</td><td class="day" data-date="1588118400000">29</td><td class="day" data-date="1588204800000">30</td><td class="new day" data-date="1588291200000">1</td><td class="new day" data-date="1588377600000">2</td></tr><tr><td class="new day" data-date="1588464000000">3</td><td class="new day" data-date="1588550400000">4</td><td class="new day" data-date="1588636800000">5</td><td class="new day" data-date="1588723200000">6</td><td class="new day" data-date="1588809600000">7</td><td class="new day" data-date="1588896000000">8</td><td class="new day" data-date="1588982400000">9</td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-months" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">«</th><th colspan="5" class="datepicker-switch">2020</th><th class="next">»</th></tr></thead><tbody><tr><td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month">Mar</span><span class="month focused">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-years" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">«</th><th colspan="5" class="datepicker-switch">2020-2029</th><th class="next">»</th></tr></thead><tbody><tr><td colspan="7"><span class="year old">2019</span><span class="year focused">2020</span><span class="year">2021</span><span class="year">2022</span><span class="year">2023</span><span class="year">2024</span><span class="year">2025</span><span class="year">2026</span><span class="year">2027</span><span class="year">2028</span><span class="year">2029</span><span class="year new">2030</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-decades" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">«</th><th colspan="5" class="datepicker-switch">2000-2090</th><th class="next">»</th></tr></thead><tbody><tr><td colspan="7"><span class="decade old">1990</span><span class="decade">2000</span><span class="decade">2010</span><span class="decade focused">2020</span><span class="decade">2030</span><span class="decade">2040</span><span class="decade">2050</span><span class="decade">2060</span><span class="decade">2070</span><span class="decade">2080</span><span class="decade">2090</span><span class="decade new">2100</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div><div class="datepicker-centuries" style="display: none;"><table class="table-condensed"><thead><tr><th colspan="7" class="datepicker-title" style="display: none;"></th></tr><tr><th class="prev">«</th><th colspan="5" class="datepicker-switch">2000-2900</th><th class="next">»</th></tr></thead><tbody><tr><td colspan="7"><span class="century old">1900</span><span class="century focused">2000</span><span class="century">2100</span><span class="century">2200</span><span class="century">2300</span><span class="century">2400</span><span class="century">2500</span><span class="century">2600</span><span class="century">2700</span><span class="century">2800</span><span class="century">2900</span><span class="century new">3000</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr><tr><th colspan="7" class="clear" style="display: none;">Clear</th></tr></tfoot></table></div></div></div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer text-black">
              <div class="row">
                <div class="col-sm-6">

                </div>

              </div>

            </div>
          </div>
          </div>
        <div class="col-md-4">
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">FEE COLLECTION OF THE DAY</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <p>Total Collection (Today) :  {{$todaytotalfee}}</p>
              <p>Total Collection (Month) :  {{$monthtotalfee}}</p>
            </div>
            <!-- /.box-body -->
          </div>

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Student Attendeance of the day</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <p>Total Present (Today) :  {{$attendance[0]->present}}</p>
              <p>Total Absent (Today) :  {{$attendance[0]->absent}}</p>
            </div>
            <!-- /.box-body -->
          </div>

          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Notice Board</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="min-height: 222px;">
            <ul>
            <li>
            <p>All Acadmic activity is Suspendended due to COVID-19</p>
            </li>
            </ul>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        </div>




        </div>
        <!-- /.col -->
        <div class="col-md-8" >
                 <div class="box">
                   <div class="box-header">
                     <h3 class="box-title">Task manager</h3>
                   </div>
                   <!-- /.box-header -->
                   <div class="box-body">
                     <table id="example" class="table table-striped table-bordered display nowrap">
                       <thead>
                       <tr>
                         <th>Sl.No</th>
                         <th>Task Description</th>
                         <th>Priority</th>
                         <th>Action</th>

                       </tr>
                       </thead>
                       <tbody>
                       <tr>
                         <td>Trident</td>
                         <td>Internet
                           Explorer 4.0
                         </td>
                         <td>Win 95+</td>
                         <td>
                       <div class="btn-group">
                         <button type="button" class="btn btn-default  btn-flat dropdown-toggle" data-toggle="dropdown">
                           <span class="caret"></span>
                           <span class="sr-only">Toggle Dropdown</span>
                         </button>
                         <ul class="dropdown-menu" role="menu" title="Action">
                           <li><a href="#" title="Edit"><i  class="fa fa-eye" style="color: #897df8e6";></i></a></li>
                           <li><a href="#" title="Delete"><i class="fa fa-trash" style="color: red";></i></a></li>
                         </ul>
                       </div>
                       </td>

                       </tr>
                       <tr>
                         <td>Trident</td>
                         <td>Internet
                           Explorer 5.0
                         </td>
                         <td>Win 95+</td>
                         <td>
                       <div class="btn-group">
                         <button type="button" class="btn btn-default  btn-flat dropdown-toggle" data-toggle="dropdown">
                           <span class="caret"></span>
                           <span class="sr-only">Toggle Dropdown</span>
                         </button>
                         <ul class="dropdown-menu" role="menu" title="Action">
                           <li><a href="#" title="Edit"><i  class="fa fa-eye" style="color: #897df8e6";></i></a></li>
                           <li><a href="#" title="Delete"><i class="fa fa-trash" style="color: red";></i></a></li>
                         </ul>
                       </div>
                       </td>
                        </tr>
                        </tbody>

                     </table>
                   </div>
                   <!-- /.box-body -->




                 </div>



                 <!-- /.box -->
               </div>


 <div class="col-md-4" >
                 <div class="box">
                    <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">To Do List</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>

                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">New</button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <ul>
            <li>
            <p>Meeting with Teachers</p>
            </li>
            </ul>
            </div>
            <!-- /.box-body -->
          </div>
</div>
</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add New To Do List</h4>
      </div>
      <div class="modal-body">
        <p></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

           </div>
            </div>

      </div>
    </section>
    @else
 <section id="other"  class="content" style="min-height: 1509px !important;">
 </section>

    @endif
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection
{{--External Style Section--}}
@section('script')
<!--<script src="http://code.jquery.com/jquery-1.10.2.min.js" integrity="sha256-C6CB9UYIS9UJeqinPHWTHVqh/E1uhG5Twh+Y5qFQmYg="
			  crossorigin="anonymous"></script>-->
<script src="{{ URL::asset('assets/dist/js/highcharts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/jszip.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/pdfmake.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/vfs_fonts.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.html5.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/buttons.print.min.js') }}"></script>
<script src="{{ URL::asset('assets\bower_components\datatables.net-bs\js\dataTables.responsive.min.js') }}"></script>
<script src="{{ URL::asset('assets/bower_components/datatables.net-bs/js/dataTables.rowReorder.min.js') }}"></script>

<script>
$(document).ready(function() {
   $.extend($.fn.dataTable.defaults, {
 dom: 'Bfrtip'
});
   $('#example').DataTable( {

       buttons: [
           'copy', 'csv', 'excel', 'pdf', 'print'
       ],
         rowReorder: {
           selector: 'td:nth-child(2)'
       },
       responsive: true


   } );
   } );

</script>
<script>
    $(document).ready(function () {
        var get_expense = <?php echo $feecollection; ?>;
        var tot_days=<?php echo $d ; ?>;
      //  alert(tot_days);
        var i=1;
        var get_expense_days = [
         <?php for($i=1;$i<=$d;$i++)
            {
                if($i!=$d)
                echo "{ day: $i, val: [] },";
                else
                 echo "{ day: $i, val: [] }";
            }

            ?>
        ];
      //  var data=JSON.parse(get_expense_days);
    //  alert();
//alert(get_expense);
        get_expense.forEach( function( item ) {
//alert(item.date);
          get_expense_days[new Date(item.date).getDate()-1].val.push( Number(item.amt));

        });
//alert();


get_expense_days=get_expense_days.map( function( item ) {
//item.val = 0;
 if ( item.val.length > 0 ) {
                item.val = item.val.reduce(function(a) {
                    return a;
                });
            } else {
                item.val = 0;
            }
                return item;
            });
        var get_expense_months = get_expense_days.map(function(item){
            return item.day;
        });

        var get_expense_amounts = get_expense_days.map(function(item){
            return item.val;
        });

      var cc=  Highcharts.chart('expense', {
            chart: {
    type: 'line'
},

            title: {
                text: ''
            },

            credits: {
                enabled: false
            },

            xAxis: {
                categories: [<?php for($i=1;$i<=$d;$i++){echo "'".$i."'," ;} ?>]
            },

            yAxis: {
                title: {
                    text: 'Amount'
                }
            },
            plotOptions: {
                line: {
        dataLabels: {
            enabled: true
        },
        enableMouseTracking: true
    },


            },

            series: [{
                name: 'Fee Collection',
                data: get_expense_amounts

            }
            ]

        });


    });
</script>
@endsection
<!-- ./wrapper -->
